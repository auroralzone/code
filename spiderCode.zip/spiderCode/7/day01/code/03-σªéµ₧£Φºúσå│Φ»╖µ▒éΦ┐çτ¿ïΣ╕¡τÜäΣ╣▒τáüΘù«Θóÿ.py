import requests

response = requests.get('http://www.baidu.com')
# # 中国的网站现在80%都是使用utf8进行编码
print(response.content.decode())
# 在中国20%网站使用 GBK gb2312是GBK的子集
# print(response.content.decode('gbk'))

# response = requests.get('http://roll.news.sina.com.cn/s/channel.php?ch=01#col=89&spec=&type=&ch=01&k=&offset_page=0&offset_num=0&num=60&asc=&page=1')
# 在中国20%网站使用 GBK gb2312是GBK的子集
# print(response.content.decode('gbk'))