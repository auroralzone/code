from selenium import webdriver
from selenium.webdriver.chrome.options import Options

# Options对象
options = Options()
# 设置浏览器无界面
options.set_headless()

# 创建浏览器驱动
driver = webdriver.Chrome(options=options)

driver.get('http://www.baidu.com')

# 可以保存快照
driver.save_screenshot('baidu.png')

# 退出浏览器
driver.quit()