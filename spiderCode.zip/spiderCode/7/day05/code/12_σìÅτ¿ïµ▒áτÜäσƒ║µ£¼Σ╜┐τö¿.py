# 猴子补丁: 让耗时操作, IO,sleep, ...自动切换
from gevent import monkey
monkey.patch_all()

# 导入协程池
from gevent.pool import Pool

import time

# 创建协程程池对象
pool = Pool()

def func(mes):
    for i in range(0, 10):
        print(mes)
        1 / 0
        time.sleep(0.001)


# 执行同步任务, 一个完成了才执行下一个
# func这个任务交给线程, 线程池分配线程来执行这个任务
# pool.apply(func, args=('任务1', ))
# pool.apply(func, args=('任务2', ))


# 执行异步任务, 不阻塞主线程
pool.apply_async(func, args=('任务1', ))
pool.apply_async(func, args=('任务2', ))
# 线程池中错误处理:
 # 当线程池中执行任务的时候, 如果子线程报错了, 它就直接结束字线程, 错误信息会通过error_callback方法返回给你

# 协程池, 如果协程任务报错, 直接报错了, 没有error_callback
# 推荐: 无论线程池,还是协程池中的错误, 你都直接使用try处理就可以了...
# 将来你进行线程池, 协程池 ...直接就可以无缝切换

# 让池中协程全部加入主线中
pool.join()
