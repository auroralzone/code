from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import json

'''
需求: 列表页中租房信息的图片URL, 标题, 详情URL, 价格

分析:
  1. 创建driver对象
  2. 请求租房的首页
    # http://sz.58.com/chuzu/
  3. 通过driver对象,解析内容, 获取需要的数据
  4. 保存数据
  5. 实现翻页
    找到下一页按钮进行点击, 页面会自动跳转下一页, 然后再获取内容即可
  6. 退出
'''


class ZuFangSpider(object):
    def __init__(self):
        # 创新配置选项对象
        op = Options()
        op.set_headless()

        # 1. 创建driver对象
        self.driver = webdriver.Chrome(options=op)

        # 2. 请求租房的首页
        self.driver.get('http://sz.58.com/chuzu/')

    def __del__(self):
        pass
        # 当对象销毁的时候, 调用
        # self.driver.quit()
        # 在退出浏览器时,但是python进程已经开始关闭了

    def get_data(self):
        '''  3. 通过driver对象,解析内容, 获取需要的数据'''
        # 先分组, 再提取内容
        # 获取出租信息的li标签列表, 后两个不要
        li_s = self.driver.find_elements_by_xpath('/html/body/div[4]/div[1]/div[5]/div[2]/ul/li')[:-2]
        # 遍历列表提取内容
        # 创建列表, 用于存储提取到的数据
        data_list = []
        for li in li_s:
            # 过滤掉光高的li标签
            if li.get_attribute('class') == 'apartments-pkg apartments':
                # 跳过本次循环, 后面的语句, 继续下一次循环
                continue

            # 图片URL, 标题, 详情URL, 价格
            item = {}
            item['img_url'] = li.find_element_by_xpath('./div[1]/a/img').get_attribute('src')
            # 标题
            item['title'] = li.find_element_by_xpath('./div[2]/h2/a').text
            # 详情URL
            item['detail_url'] = li.find_element_by_xpath('./div[2]/h2/a').get_attribute('href')
            # 价格
            item['price'] = li.find_element_by_xpath('./div[3]/div[2]/b').text
            # print(item)
            data_list.append(item)

        # 获取下一页按钮
        # 使用find_elements, 原因是最后一页没有下一页的按钮, 但是我们不希望报错,导致程序结束
        next_page = self.driver.find_elements_by_class_name('next')
        next_page = next_page[0] if len(next_page) != 0 else None

        return data_list, next_page

    def save_data(self, data_list):
        '''4. 保存数据'''
        # 一个租房信息以json格式保存到一行
        with open('58zufang.txt', 'a', encoding='utf8') as f:
            for data in data_list:
                json.dump(data, f, ensure_ascii=False)
                f.write('\n')

    def run(self):

        while True:
            #   3. 通过driver对象,解析内容, 获取需要的数据
            print(self.driver.current_url)
            data_list, next_page = self.get_data()
            #   4. 保存数据
            self.save_data(data_list)
            #   5. 实现翻页
            if next_page is not None:
                next_page.click()
            else:
                break

        # 在这个位置退出
        self.driver.quit()


if __name__ == '__main__':
    zfs = ZuFangSpider()
    zfs.run()
