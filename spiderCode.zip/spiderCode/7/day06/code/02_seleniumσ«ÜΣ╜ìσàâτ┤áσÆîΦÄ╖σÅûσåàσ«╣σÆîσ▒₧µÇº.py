from selenium import webdriver
import time

# 创建浏览器驱动
driver = webdriver.Chrome()
# 访问页面
driver.get('http://www.baidu.com')

# 通过id定位元素
# input_element = driver.find_element_by_id('kw')
# 通过name属性定位元素
# input_element = driver.find_element_by_name('wd')
# 通过xpath定位元素
# input_element = driver.find_element_by_xpath('//*[@id="kw"]')
# 给输入框设置内容
# input_element.send_keys('python')

# 根据文本获取标签
hao123 = driver.find_element_by_link_text('hao123')
# 获取标签中的文本
print(hao123.text)

# 根据部分文本获取标签
hao123 = driver.find_element_by_partial_link_text('hao')
# 获取属性
print(hao123.get_attribute('href'))

# 根据selector进行定位(了解)
hao123 = driver.find_element_by_css_selector('#u1 > a:nth-child(2)')
print(hao123.text)

# 获取多个标签
a_s = driver.find_elements_by_xpath('//*[@id="u1"]/h3')
# 遍历a_s
for a in a_s:
    print(a.text)
    print(a.get_attribute('href'))

# find_element 与 find_elements区别:
# - find_element 只获取一个元素, 如果有多个就获取第一个, 如果没有就报错了
# - find_elements 获取定位元素列表, 如果没有就返回一个空列表


time.sleep(2)
# 强调: 一旦报错了, 后面的代码不走, 浏览和驱动都没有退出
driver.quit()