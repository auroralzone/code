from selenium import webdriver
import time

# 创建驱动
driver = webdriver.Chrome()

# QQ邮箱登录也么
driver.get('https://mail.qq.com/')

# driver不能直接获取页面中iframe中元素, 因为每一个iframe独立页面
# 如果要获取iframe中元素就需要把driver切换iframe上
#  by index(索引), name(属性name的值), or webelement(通过driver对象获取iframe元素进行定位)
driver.switch_to.frame('login_frame')
# driver.switch_to_frame() 过时了

# 找到用户输入框, 输入用户名
driver.find_element_by_id('u').send_keys('deshanlee@qq.com')
# 找到密码输入框, 输入密码
driver.find_element_by_id('p').send_keys('lw19860404')

# 找到登录, 进行点击
driver.find_element_by_id('login_button').click()


time.sleep(3)
# 退出驱动
driver.quit()

