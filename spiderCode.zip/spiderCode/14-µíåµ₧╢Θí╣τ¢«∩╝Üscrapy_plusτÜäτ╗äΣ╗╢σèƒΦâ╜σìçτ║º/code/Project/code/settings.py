#coding:utf-8

DEFAULT_LOG_FILENAME = 'baidu.log'    # 默认日志文件名称
