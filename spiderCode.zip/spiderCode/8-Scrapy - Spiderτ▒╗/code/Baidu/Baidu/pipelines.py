# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


class BaiduMongoDBPipeline(object):
    def open_spider(self, spider):
        self.client = pymongo....

    def process_item(self, item, spider):
        self.client.insert(dict(item))
        return item

    def close_spider(self, spider):
        self.file.close()

class BaiduJsonPipeline(object):
    def process_item(self, item, spider):
        return item


#settings.py



pipeline = BaiduMongoDBPipeline()

pipeline.open_spider(spider)
pipeline.process_item(item, spider)
pipeline.process_item(item, spider)
pipeline.process_item(item, spider)
pipeline.process_item(item, spider)
pipeline.process_item(item, spider)
pipeline.process_item(item, spider)
pipeline.process_item(item, spider)
pipeline.process_item(item, spider)
pipeline.process_item(item, spider)
pipeline.close_spider(spider)



