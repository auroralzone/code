import requests

# 发送请求,获取响应
response = requests.get('http://www.baidu.com')

# 查看编码方式
# print(response.encoding) # ISO-8859-1: 拉丁文(西欧)
# response.encoding = 'utf8'
# # 获取文本字符串
# print(response.text)

# 获取二进制, 解码
print(response.content.decode())

# 获取状态吗
print(response.status_code)

# 获取响应的URL
print(response.url)

# 获取响应头
print(response.headers)

# 获取请求的URL
print(response.request.url)
# 获取请求头
print(response.request.headers)