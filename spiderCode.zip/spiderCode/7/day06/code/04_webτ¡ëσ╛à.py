from selenium import webdriver
import time

driver = webdriver.Chrome()

# 访问百度首页
driver.get('http://www.baidu.com')

# 搜索传智播客
driver.find_element_by_id('kw').send_keys('传智播客')
# 点击搜索按钮
driver.find_element_by_id('su').click()

# driver只有get方法请求的时候,才会等待页面加载完毕
# 如果通过点击按钮跳转的页面, 我们获取元素,是不会等待页面加载完成
# web等待就是等待页面加载
# 等待有三种方式:
# 方式1; 强制等待
# time.sleep(2)
# 方式2: 隐式等待
# 等待页面加载完成或3s的时间到了
# driver.implicitly_wait(3)
# 方式3: 显示等待, 等待到满足某个条件的时候为止(了解)
# 注意事项: 如果页面的内容是通过js生成的,那么隐式等待和显示等待都是无效, 只能使用强制等待

# 获取下一页
next_btn = driver.find_element_by_partial_link_text('下一页')
next_btn.click()


time.sleep(2)
driver.quit()

