import requests
import re


'''
 - 获取所有段子写到文件中,每个段子占一行
 步骤:
   准备URL
    http://www.neihanpa.com/article/list_5_1.html
   发送请求获取数据
   解析数据
   保存数据
   分页
'''

class NeihanDanZiSpider(object):

    def __init__(self):
        # 让URL变化的部分使用{}进行占位
        self.url = 'http://www.neihanpa.com/article/list_5_{}.html'
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
        }
        # 生成一个URL列表
        self.url_list = [self.url.format(i) for i in range(1, 507)]

    def get_page_from_url(self, url):
        ''' # 发送请求获取数据'''
        response = requests.get(url, headers=self.headers)
        return response.content.decode('gbk')

    def get_dz_list_from_page(self, page):
        '''解析数据, 获取段子列表'''
        '''
        <div class="f18 mb20">
                            　　第一次心理课，心理老师姓赵，名海燕。<br>
　　自我介绍：“我姓赵，名呢，和你们一篇语文课文的题目一样。”<br>
　　于是一同学高喊：“赵州桥！”
                            
                        </div>
        '''
        dz_list = re.findall('<div class="f18 mb20">(.+?)</div>', page, re.S)
        for dz in dz_list:
            # 获取段子在列表中索引
            index = dz_list.index(dz)
            # 删除 <.*>|\s
            dz = re.sub('<.*>|\s', '', dz)
            # &ldquo; 或 &rdquo; 替换为 "
            dz = re.sub('&ldquo;|&rdquo;', '"', dz)
            # &hellip; 替换为 …
            dz = re.sub('&hellip;', '...', dz)
            dz_list[index] = dz

        return dz_list

    def save_data(self, dz_list):
        '''# 保存数据'''
        with open('neihanba_dz.txt', 'a', encoding='utf8') as f:
            for dz in dz_list:
                f.write(dz)
                f.write('\n')

    def run(self):
        #  准备URL
        #  http://www.neihanpa.com/article/list_5_1.html
        for url in self.url_list:
            # 发送请求获取数据
            page = self.get_page_from_url(url)
            # 解析数据
            dz_list = self.get_dz_list_from_page(page)
            # 保存数据
            self.save_data(dz_list)
            # 分页


if __name__ == '__main__':
    nhdzs = NeihanDanZiSpider()
    nhdzs.run()