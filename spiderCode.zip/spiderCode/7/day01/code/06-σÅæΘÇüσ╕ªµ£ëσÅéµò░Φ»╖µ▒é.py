import requests

wd = input('请求你要输入的内容:')

headers ={
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
}

# 方案1 : 拼接URL
# url = 'https://www.baidu.com/s?wd=%s'
# url % wd
# 推荐(比较)
# url = 'https://www.baidu.com/s?wd={}'
# url = url.format(wd)
#
#

# response = requests.get(url, headers=headers)
#
# print(response.content.decode())

# 方案2: 通过params参数传递

params = {
   'wd': wd
}

response = requests.get('https://www.baidu.com/s', params=params, headers = headers)
print(response.content.decode())