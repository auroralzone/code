import requests


# 准备URL
url = 'http://httpbin.org/post'

# 准备数据
data = {
    'name': 'lao wang'
}


# 发送请求, 获取响应
response = requests.post(url, data=data)

print(response.content.decode())
