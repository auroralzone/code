#coding:utf-8


class Pipeline(object):
    def process_item(self, item):
        print("Item : {}".format(item.data))
