#coding:utf-8


from scrapy_plus.core.engine import Engine


if __name__ == "__main__":
    engine = Engine()
    engine.start()
