# 猴子补丁
from gevent import monkey
monkey.patch_all()
from gevent.pool import Pool



from queue import Queue
import time

# 创建队列对象
queue = Queue()

# 定义方法, 添加数据到队列中
def add_to_queue():
    for i in range(0, 100):
        print("添加{}".format(i))
        queue.put(i)

# 定义方法从队列中获取数据
def get_from_queue():
     while True:
        print(queue.get())
        time.sleep(0.0001)
        queue.task_done()


# 创建线程池对象
pool = Pool()

# 执行异步任务
pool.apply_async(add_to_queue)
pool.apply_async(get_from_queue)

# 一但池子关闭, 就不能添加任务了
# pool.close()
# pool.join()

# 等待 : 主线执行快, 子线程还没有执行, 那么queue就是空的, 就没有任务.
time.sleep(0.001)
queue.join()