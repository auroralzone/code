import requests
import json
import js2py

'''
 只要这个代码写熟, 你基本上可以解决90%的js反爬
 selenium 
'''

class RRLoginSpider(object):

    def __init__(self):
        # 登录URL
        self.clog_url = 'http://activity.renren.com/livecell/ajax/clog'
        # rkeyURL
        self.rkey_url = 'http://activity.renren.com/livecell/rKey'
        # 创建session
        self.session = requests.session()

        # 请求头
        # i.setRequestHeader("X-Requested-With", "XMLHttpRequest"),
        # i.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"),
        self.session.headers = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Mobile Safari/537.36',
            "X-Requested-With": "XMLHttpRequest",
            "Content-Type": "application/x-www-form-urlencoded",
        }

        # 创建js执行环境
        self.context = js2py.EvalJs()


    def get_data_from_url(self, url, data=None):
        '''根据URL返回对应数据'''
        if data is None:
            # 如果没有就发送get请求
            response = self.session.get(url)
        else:
            response = self.session.post(url, data=data)

        return response.content # 返回响应的二进制数据

    def load_js_from_url(self, url):
        '''根据URL让我们js执行环境去加载js'''
        js = self.get_data_from_url(url).decode()
        # 让我们js执行环境, 去执行这段js, 也就是把这点js的执行环境中
        self.context.execute(js)

    def run(self):
        '''程序入口, 主干逻辑'''
        # 准备登录URL:
        #   http://activity.renren.com/livecell/ajax/clog
        # 准备登录数据
        #   rkey请求URL: http://activity.renren.com/livecell/rKey
        #   返送请求获取数据
        rkey_json = self.get_data_from_url(self.rkey_url)
        # print(rkey_json)
        #   解析获取data中数据,赋值n
        n = json.loads(rkey_json)['data']
        #   首先使用js2py创建js执行环境context
        #   向js执行环境中添加数据: t(phoneNum, password, c1),n
        self.context.t = {
            'phoneNum':'15565280933',
            'password': 'a123456',
            'c1':0
        }
        self.context.n = n
        #   让js执行环境去加载需要js
        #   http://s.xnimg.cn/a85738/wap/mobile/wechatLive/js/BigInt.js
        self.load_js_from_url('http://s.xnimg.cn/a85738/wap/mobile/wechatLive/js/BigInt.js')
        self.load_js_from_url('http://s.xnimg.cn/a85738/wap/mobile/wechatLive/js/RSA.js')
        self.load_js_from_url('http://s.xnimg.cn/a85738/wap/mobile/wechatLive/js/Barrett.js')
        # 加密密码js
        js = '''
              t.password = t.password.split("").reverse().join(""),
              setMaxDigits(130);
              var o = new RSAKeyPair(n.e,"",n.n)
                , r = encryptedString(o, t.password);
              t.password = r,
              t.rKey = n.rkey
          '''
        #   执行js, 执行后执行环境中t就是我们要发送登录请数据
        self.context.execute(js)
        # print(self.context.t)
        # print(type(self.context.t)) # <class 'js2py.base.JsObjectWrapper'>
        # print(dir(self.context.t))
        #   发送登录请求,获取登录后的数据
        result = self.get_data_from_url(self.clog_url, data=self.context.t.to_dict())
        print(json.loads(result))

        # 使用登录后的ssesion访问登录后的资源
        response = self.session.get('http://activity.renren.com/myprofile')
        with open('home.html', 'wb') as f:
            f.write(response.content)



if __name__ == '__main__':
    rrs = RRLoginSpider()
    rrs.run()

