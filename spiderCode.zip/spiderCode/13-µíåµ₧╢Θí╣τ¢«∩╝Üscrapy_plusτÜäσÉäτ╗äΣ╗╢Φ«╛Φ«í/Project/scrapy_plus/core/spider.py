#coding:utf-8

#from scrapy_plus.http.request import Request
from ..http.request import Request
from ..item import Item

class Spider(object):
    """
        提供的Spider类，做为程序的入口
    """

    start_url = "http://www.baidu.com"

    def start_requests(self):
        return Request(self.start_url)


    def parse(self, response):
        item = Item(response.body)
        return item

        return Request()
