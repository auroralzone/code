import json

json_str = '{"name":"lao wang", "age":10, "gender":true, "desc":"老王在炼妖"}'

# 把json字符串转换为python
dic = json.loads(json_str)
print(type(dic)) # <class 'dict'>
print(dic)

# 把python类型转换为json字符
# json_str = json.dumps(dic)
# 该方法默认使用ASCII进行编码的
# ensure_ascii: 要不要使用ascii编码,默认True, 如果指定为False,就是使用UTF-8进行编码o's
# indent: 启用json格式化,指定数字表示缩进的空格数
json_str = json.dumps(dic, ensure_ascii=False, indent=4)
print(type(json_str)) # <class 'str'>
print(json_str)

# 操作文件
# 把python类型的数据以json格式写到文件中
with open('test.json', 'w', encoding='utf8') as f:
     # json.dump(dic, f)
     # json.dump(dic, f, ensure_ascii=False)
     json.dump(dic, f, ensure_ascii=False, indent=4)

# 从文件中读取json数据转换为python类型
with open('test.json', 'r', encoding='utf8') as f:
    dic = json.load(f)
    print(dic)