from selenium import webdriver
import time

# 创建浏览器驱动对象
driver = webdriver.Chrome()
# 请求URL
driver.get('http://sz.58.com/chuzu/')

# 实现滚动页面效果
js = "window.scrollTo(0, {})"



# 实现滚动四次, 每次滚500
for i in range(1, 5):
    # 拼接字符串
    command = js.format(i*500)
    # 执行js
    driver.execute_script(command)
    # 睡1s
    time.sleep(1)

# 退出
driver.quit()

