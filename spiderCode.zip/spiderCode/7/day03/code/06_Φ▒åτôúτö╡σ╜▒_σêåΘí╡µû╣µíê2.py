import requests
import json

class DoubanMovieSpider(object):

    def __init__(self):
         # URL
         # start的值要使用{}占位
         self.url = 'https://m.douban.com/rexxar/api/v2/subject_collection/movie_showing/items?start={}&count=18&loc_id=108288'
         # 准备请求头
         self.headers = {
             'Referer': 'https://m.douban.com/movie/nowintheater?loc_id=108288',
             'User-Agent': 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Mobile Safari/537.36'
        }

    def get_data_from_url(self, url):
        '''根据URL,获取URL对应二进制数据'''
        response = requests.get(url, headers=self.headers)
        return response.content

    def get_movie_list(self, json_str):
        ''' 解析json数据, 获取电影信息列表'''
        dic = json.loads(json_str)
        # print(dic)
        # 计算下一页start
        # start: 本页起始索引
        start = dic['start']
        # count: 本页请求的数据条数
        count = dic['count']
        # total: 总条数
        total = dic['total']
        # 计算下一页索引
        next_start = start + count
        print(next_start)
        # 下一页的开始索引号大于等于总条数, 就说明没有下一页
        if next_start >= total:
            next_start = None

        return dic['subject_collection_items'], next_start

    def save_movie_list(self, move_list):
        '''把电影信息存储文件, 每一个电影信息占一行'''
        with open('douban_movie2.txt', 'a', encoding='utf8') as f:
             for movie in move_list:
                json.dump(movie, f, ensure_ascii=False)
                f.write('\n')

    def run(self):
        '''入口'''

        # 准备URL
        #  - 热映电影json数据URL
        #  https://m.douban.com/rexxar/api/v2/subject_collection/movie_showing/items?start=0&count=18&loc_id=108288
        # 定义start变量
        start = 0

        while start is not None:
            # 发送请求,获取数据
            url = self.url.format(start)
            # print(url)
            json_str = self.get_data_from_url(url)
            # print(json_str)
            # 解析json数据, 获取电影信息列表
            movie_list, start = self.get_movie_list(json_str)
            # print(movie_list)
            # 把电影信息存储文件, 每一个电影信息占一行
            self.save_movie_list(movie_list)




if __name__ == '__main__':
    dbms = DoubanMovieSpider()
    dbms.run()
