# -*- coding: utf-8 -*-
import scrapy


class RenrenCookiesSpider(scrapy.Spider):
    name = 'renren_cookies'
    allowed_domains = ['renren.com']
    start_urls = [
        'http://www.renren.com/327550029/profile',
        'http://www.renren.com/410043129/profile'
    ]

    headers = {
        "Accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
        "Accept-Encoding" : "gzip, deflate",
        "Accept-Language" : "zh-CN,zh;q=0.9,en;q=0.8",
        "Cache-Control" : "max-age=0",
        "Connection" : "keep-alive",
        "Host" : "www.renren.com",
        "Upgrade-Insecure-Requests" : "1",
        "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36"
    }

    cookies = {
        "anonymid" : "j7wsz80ibwp8x3",
        "_r01_" : "1",
        "_de" : "BF09EE3A28DED52E6B65F6A4705D973F1383380866D39FF5",
        "depovince" : "GW",
        "jebecookies" : "0baf6adb-8726-4e6b-baeb-0e1bf0dfc67f|||||",
        "ick_login" : "e9deccb1-218f-41d1-9b1f-37d39ff18e3f",
        "p" : "1f8dc2bbdd9ef96842f4c74028f0e0199",
        "first_login_flag" : "1",
        "ln_uact" : "mr_mao_hacker@163.com",
        "ln_hurl" : "http://hdn.xnimg.cn/photos/hdn121/20180607/2035/main_voFQ_aec80000bd2a1986.jpg",
        "t" : "83565252544098cdf930ca79a793e8509",
        "societyguester" : "83565252544098cdf930ca79a793e8509",
        "id" : "327550029",
        "xnsid" : "22abb1f3",
        "loginfrom" : "syshome",
        "ch_id" : "10016",
        "wp_fold" : "0"
    }


    def start_requests(self):
        # 发送start_urls的请求，并附带登录状态的Cookies
        for url in self.start_urls:
            yield scrapy.Request(url, headers = self.headers, cookies = self.cookies, dont_filter=True)

    def parse(self, response):
        filename = response.xpath("//head/title/text()").extract_first()

        with open(filename + ".html", "w") as f:
            f.write(response.body)
