# 导入线程池模块
from multiprocessing.dummy import Pool
import time


# 创建线程池对象
# 如果你没有指定线程的个数, 默认就是CPU的个数
# pool = Pool()
# 指定线程池中线程的个数
pool = Pool(6)


def func(mes):
    for i in range(0, 10):
        print(mes)
        1 / 0
        time.sleep(0.001)


# 执行同步任务, 一个完成了才执行下一个
# func这个任务交给线程, 线程池分配线程来执行这个任务
# pool.apply(func, args=('任务1', ))
# pool.apply(func, args=('任务2', ))


# 执行异步任务, 不阻塞主线程
# pool.apply_async(func, args=('任务1', ))
# pool.apply_async(func, args=('任务2', ))
# 线程池中错误处理:
 # 当线程池中执行任务的时候, 如果子线程报错了, 它就直接结束字线程, 错误信息会通过error_callback方法返回给你

def error_callback(e):
    print(e)
    print(type(e))

pool.apply_async(func, args=('任务1', ), error_callback=error_callback)
pool.apply_async(func, args=('任务2', ), error_callback=error_callback)

# 关闭线程, 就不能添加新任务了
pool.close()
# 让池中线程全部加入主线中
pool.join()
