from lxml import etree

text = '''
<div> <ul>
<li class="item-1"><a >first item</a></li>
<li class="item-1"><a href="link2.html">second item</a></li>
<li class="item-inactive"><a href="link3.html">third item</a></li>
<li class="item-1"><a href="link4.html">fourth item</a></li>
<li class="item-0"><a href="link5.html">fifth item</a>
</ul> </div>

'''

# 把字符串的html转为为lxml中Element对象
element = etree.HTML(text)

# 获取属性为item-1的li标签下的a标签的href属性

hrefs = element.xpath('//li[@class="item-1"]/a/@href')
print(hrefs)

# 获取属性为item-1的li标签下的a标签的文本
texts = element.xpath('//li[@class="item-1"]/a/text()')
print(texts)

# 把每一个a标签的文本和href组装为字典

for href in hrefs:
    item = {}
    item['href'] = href
    item['title'] = texts[hrefs.index(href)]
    print(item)

# 如果根据索引进行匹配,那么如果一个数据缺失,所有数据都错了.

