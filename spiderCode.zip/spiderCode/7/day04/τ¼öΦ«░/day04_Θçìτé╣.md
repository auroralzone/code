
# 果壳爬虫
  需求: 爬去果壳网所有精彩问答的标题和URL
  步骤:
    准备URL
      https://www.guokr.com/ask/highlight/
    发送请求获取页面数据
    解析数据, 提取需要的内容
    <h2><a target="_blank" href="https://www.guokr.com/question/668948/">子弹能射穿多少本书，与那一摞书本的本数多少有何关系？</a></h2>
    保存数据
    分页:
      方案1:  
        URL规律明显
        https://www.guokr.com/ask/highlight/?page=1
        https://www.guokr.com/ask/highlight/?page=2
        https://www.guokr.com/ask/highlight/?page=3
        并且页数就是100页,固定
        可以使用URL列表
      方案2:
        我们可以从上一页的数据中,提取出来下一页URL
        1. 在解析数据的时候,提取下一页的URL
        2. 交给run方法
        3. 如果有下一页的URL就循环, 否则结束循环

# 36kr首页新闻信息
36氪练习
   获取36氪的首页信息
   # 准备URL
      http://36kr.com/
   # 发送请求, 获取数据
   # 解析数据,提取需要内容
      <script>var props=(.+?)</script>
   # 保存数据

# 内涵吧

# 内涵吧段子
 - 获取所有段子写到文件中,每个段子占一行 
 步骤:
   准备URL
    http://www.neihanpa.com/article/list_5_1.html
   发送请求获取数据
   解析数据
   '''
   <div class="f18 mb20">
                            　　第一次心理课，心理老师姓赵，名海燕。<br>
　　自我介绍：“我姓赵，名呢，和你们一篇语文课文的题目一样。”<br>
　　于是一同学高喊：“赵州桥！”
                            
                        </div>
   '''
   保存数据
   分页
     http://www.neihanpa.com/article/list_5_1.html
     http://www.neihanpa.com/article/list_5_2.html
     http://www.neihanpa.com/article/list_5_3.html
     一共506页
     可以使用URL列表实现分页
# 总结: xpath语法中核心重点
路径:
   / 单级找出
   // 多级找出
   . 当前节点
   .. 父节点
   @属性名 获取属性值
   text() 获取文本内容
过滤(定位)
   div[@class='page'] 
   a[text()='下一页']
   a[1]
   a[last()]
   a[last()-1]
   a[position()>5]
   a[1]|a[5]
   a[contains(text(), '后页')]
获取数据
  a/@href
  a/text()


贴吧爬虫
# 需求: 获取所有主题URL和标题和详情页的所有图片

先获取单页的所有的标题和URL
准备URL:
 http://tieba.baidu.com/mo/q---8DF4A6278C21C5F331E3F89A7D56AE96%3AFG%3D1-sz%40320_240%2C-1-3-0--2--wapp_1527567444963_895/m?kw=%E6%9D%8E%E5%86%B0%E5%86%B0&lp=5011&lm=&pn=40
发送请求,获取数据
提取数据, URL和标题列表
保存数据



