import threading
import time

# 定一个方法
def func():
    for i in range(0, 10):
        # threading.current_thread() 获取当前的线程, 执行这行代码的那个线程对象
        print(threading.current_thread().getName())
        time.sleep(0.001)

# 创建对象对象
t1 = threading.Thread(target=func)
# 设置子线程为守护线程
t1.setDaemon(True)
t1.start()

t2 = threading.Thread(target=func)
t2.setDaemon(True)
t2.start()

# 我希望主线结束了, 子线程自动结束, 需要怎么办呢?
# 把子线程设置守护线程

# 让子线程加入到主线程, 也就是让主线等待子线程的完成
t1.join()
t2.join()

print("主线程结束了")