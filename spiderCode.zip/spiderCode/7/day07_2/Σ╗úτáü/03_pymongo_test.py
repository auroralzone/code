from pymongo import MongoClient


class MongoTest(object):

    def __init__(self):
        # 建立mongo客户链接
        # client = MongoClient('127.0.0.1', 27017)
        client = MongoClient()
        # print(client)
        # 通过客户端对象, 获取要操作集合对象
        self.collection = client['test']['t']

    def try_insert_one(self):
         '''插入一条文档'''
         self.collection.insert_one({'name':'赵丽颖', 'age':22})

    def try_insert_many(self):
        '''插入多条数据'''
        # 传输入数据: 使用装有字典列表
        datas = [{'name':'test_{}'.format(i), 'age': i}  for i in range(1, 100)]
        self.collection.insert_many(datas)

    def try_update_one(self):
        '''修改一条数据'''
        # self.collection.update_one({'name':'赵丽颖'}, {'name': '迪丽热巴'}) # 错误
        self.collection.update_one({'name':'赵丽颖'}, {'$set':{'name': '迪丽热巴'}})
    def try_update_many(self):
        '''修改多少数据, 修改满足条件的所有数据'''
        '''把年龄为22名字都改为 周冬雨'''
        self.collection.update_many({'age':22}, {'$set': {'name': '周冬雨'}})

    def try_find_one(self):
        '''查一条数据, 返回是一个字典'''
        data = self.collection.find_one({'age': 22})
        print(data)
        print(type(data))

    def try_find_many(self):
        '''查询满足条件所有数据'''
        '''返回游标对象, 可以for in或里面的元素'''
        cursor = self.collection.find({'age':22})
        # print(cursor)
        # print(type(cursor))
        for data in cursor:
            print(data)

    def try_delete_one(self):
        '''删除满足条件的1条数据'''
        self.collection.delete_one({'age':22})
    def try_delete_many(self):
        '''删除满足条件的所有数据'''
        # 删除所有年龄为22
        # self.collection.delete_many({'age': 22})
        # 删除年龄包含test
        self.collection.delete_many({'name': {'$regex': 'test'}})

if __name__ == '__main__':
    mt = MongoTest()
    # mt.try_insert_one()name
    # mt.try_insert_many()
    # mt.try_update_one()
    # mt.try_update_many()
    # mt.try_find_one()
    # mt.try_find_many()
    # mt.try_delete_one()
    mt.try_delete_many()