import requests

# reqeusts.util.dict_from_cookiejar 把cookie对象转化为字典(了解)

response = requests.get('http://www.baidu.com')
print(response.cookies) # <RequestsCookieJar[<Cookie BDORZ=27315 for .baidu.com/>]>
#  把cookie对象转化为字典
dic = requests.utils.dict_from_cookiejar(response.cookies)
print(dic)

# 字典转换cookiejar
cookiejar = requests.utils.cookiejar_from_dict(dic)
print(cookiejar)


# 如何进行URL的编码与解码
url = 'https://www.baidu.com/s?wd=%E4%BC%A0%E6%99%BA%E6%92%AD%E5%AE%A2'

# URL解码(多)
url_str = requests.utils.unquote(url) # https://www.baidu.com/s?wd=传智播客
print(url_str)

# URL编码(少), 实编码际开发中如果需要进行编码后面的参数
url = requests.utils.quote(url_str)
print(url)


# 请求 SSL证书验证
# 发送HTTPS的请求, requests模块中里面本来就有信任的证书
# 有些网站的证书可能是他们自己生成的, reqeusts模块就没有这个证书怎么办? 可以让发送请求不启用该证书
response = requests.get('https://www.12306.cn/mormhweb/', verify=False)
print(response.content)


