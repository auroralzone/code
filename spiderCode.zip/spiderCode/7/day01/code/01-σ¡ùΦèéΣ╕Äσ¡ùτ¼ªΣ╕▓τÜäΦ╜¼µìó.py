
s = '中文'

# 默认 utf-8
b = s.encode()
print(b)    # b'\xe4\xb8\xad\xe6\x96\x87'
# 标准
b = s.encode('UTF-8')
# 我开发
# b = s.encode('utf8')
print(b)    # b'\xe4\xb8\xad\xe6\x96\x87'

# 解码: 字节转字符串
s = b.decode()
s = b.decode('utf8')
print(s)    # 中文
# 报错, 编码与解码使用码表不一致
# s = b.decode('gbk')
# print(s)

gb = s.encode('GBK')
print(gb) # b'\xd6\xd0\xce\xc4'
s = gb.decode('gbk')
# s = gb.decode()
print(s)    # 中文