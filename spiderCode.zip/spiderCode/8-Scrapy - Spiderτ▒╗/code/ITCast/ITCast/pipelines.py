# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html


import json

class ItcastJsonPipeline(object):

    # 爬虫启动时执行一次
    def open_spider(self, spider):
        self.f = open("itcast_pipeline.json", "w")

    # 必须实现的，用来处理每一个item数据
    def process_item(self, item, spider):
        content = json.dumps(dict(item), ensure_ascii = False) + ",\n"
        self.f.write(content.encode("utf-8"))

        return item

    # 爬虫关闭时执行一次
    def close_spider(self, spider):
        self.f.close()



# class ItcastMongoPipeline(object):

#     # 爬虫启动时执行一次
#     def open_spider(self, spider):
#         self.f = open("itcast.json", "w")

#     # 必须实现的，用来处理每一个item数据
#     def process_item(self, item, spider):
#         content = json.dumps(item) + ",\n"
#         self.f.write(content)

#         return item





# Unicode <-> 非Unicode

# utf8_str = ""


# unicode_str = utf8_str.decode("utf-8")
# gbk_str = unicode_str.encode("gbk")


# unicode_str = gbk_str.decode("gbk")
# utf8_str = unicode_str.encode("utf-8")
