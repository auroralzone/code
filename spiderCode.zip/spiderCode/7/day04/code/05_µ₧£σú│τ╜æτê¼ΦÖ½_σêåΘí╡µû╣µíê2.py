import requests
import re
import json

'''
    方案2:
        我们可以从上一页的数据中,提取出来下一页URL
        1. 在解析数据的时候,提取下一页的URL
        2. 交给run方法
        3. 如果有下一页的URL就循环, 否则结束循环
'''

class GuokrSpider(object):

    def __init__(self):
        self.url = 'https://www.guokr.com/ask/highlight/'
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
        }
        # 由于下一页中的URL不完整, 需要进行拼接,这个就是前面的那一段
        self.pre_url = 'https://www.guokr.com'

    def get_page_from_url(self, url):
        # print(url)
        ''' # 发送请求获取页面数据'''
        response = requests.get(url, headers=self.headers)
        # 返回响应的字符串数据
        return response.content.decode()

    def get_data_from_page(self, page):
        '''# 解析数据, 提取需要的内容'''
        # <h2><a target="_blank" href="https://www.guokr.com/question/668948/">子弹能射穿多少本书，与那一摞书本的本数多少有何关系？</a></h2>

        data_list = re.findall('<h2><a target="_blank" href="(.+?)">(.+?)</a></h2>', page, re.S)

        #解析下一页的URL
        # <a href="/ask/highlight/?page=4">下一页</a>
        next_url = re.findall('<a href="(.+?)">下一页</a>', page)
        # 如果findall没有找到数据, 返回一个空列表
        next_url = self.pre_url + next_url[0] if len(next_url) != 0 else None
        # print(data_list)
        return data_list, next_url

    def save_data(self, data_list):
        '''保存数据, 一条问答保存一行'''
        with open('goukr2.txt', 'a', encoding='utf8') as f:
            for data in data_list:
                json.dump(data, f, ensure_ascii=False)
                f.write('\n')

    def run(self):
        # 准备URL
        # https://www.guokr.com/ask/highlight/
        url = self.url
        while url is not None:
            # 发送请求获取页面数据
            page = self.get_page_from_url(url)
            # 解析数据, 提取需要的内容
            data_list, url = self.get_data_from_page(page)
            # 保存数据
            self.save_data(data_list)


if __name__ == '__main__':
    gkr = GuokrSpider()
    gkr.run()