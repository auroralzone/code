import json
# json标准格式: 键和字符串都必须使用 双引号

json_str = "{'name':'lao wang', 'age':10, 'gender':true, 'desc':'老王在炼妖'}"

# 不能处理单引号的json字符串
# dic = json.loads(json_str)
# print(dic)
# 如果万一遇到json数据使用单引号, 就需要把单引号替换为双引号,再使用json模块
json_str = json_str.replace("'", '"')
# print(json_str)
dic = json.loads(json_str)
print(dic)