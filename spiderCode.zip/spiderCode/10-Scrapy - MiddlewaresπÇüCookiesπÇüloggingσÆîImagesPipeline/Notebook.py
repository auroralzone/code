
数据工程

数据获取 - 数据规整 - 数据分析 - 数据可视化



一、什么是爬虫？
一种抓取网页数据的程序。


二、爬虫的设计流程。

1. 通过网页的URL地址，发送对应的HTTP请求；
2. 获取返回的HTTP响应，保存对应的HTML页面文本；
3. 通过相关的HTML解析工具，提取网页里的数据：
  a. 如果是需要保存的目标数据，根据需求保存到对应（txt、csv、json、mongodb）
  b. 如果是需要继续抓取的URL地址，从第一步重复执行。
4. 当所有的URL地址都抓取完毕，程序结束。


三、课程介绍

1. HTTP请求处理库：requests
2. HTML解析处理库：re、xpath
3. 数据存储方案：json、csv、数据库(MongoDB)
4. 动态页面数据处理：Selenium+PhantomJS/Chrome  模拟真实浏览器来渲染页面



5. Scrapy框架 ： 是一个非常流行的高定制性高性能Python爬虫框架。
  请求发送、提取规则、数据存储、请求去重，并使用了twisted异步网络框架。


  不同的硬件环境，共享请求队列。

6. scrapy-redis 分布式策略：在Scrapy框架基础上，提供了一套以Redis数据库为核心的组件。在Redis数据库中，
    存储请求队列、请求指纹、数据。以便让不同的机器，读取同一个数据库的数据，实现分布式的功能。


7. 自定义爬虫框架：
  1. 做一个搜索引擎（Google、Baidu、Bing）：需要强大的资金、技术支持。
  2. 根据业务需求，自定义一个爬虫框架：需要技术技术支持。








Scrapy框架：

- 查看Pip版本
pip -V

- 安装Scrapy
pip install scrapy


- 更新Scrapy（先更新pip版本）
pip install pip --upgrade
pip install scrapy -- upgrade


- 卸载Scrapy
pip uninstall scrapy



workon spider_py2

1.1 scrapy startproejct xxx   middlewares.py

# Anaconda   conda install scrapy



Scrapy框架 需要处理的三大数据：
1. 请求 Request
2. 响应 Response
3. 数据 Item


Scrapy框架的基本组件：
1. items.py 用来定义保存的item数据字段
2. pipelines.py 用来编写item数据存储方案
3. middlewares.py 用来编写各个中间件
4. settings.py 用来设置当前项目的配置信息
5. spiders 目录：保存所有爬虫文件


Scrapy项目的基本使用流程：

1. 创建Scrapy项目： 执行命令 scrapy startproejct Baidu

2. 定义item数据字段： 在items.py文件中处理

3. 创建spider爬虫： 进入到spiders目录下，执行命令 scrapy genspider baidu baidu.com

4. 编写spider爬虫代码 : 打开爬虫文件，
    - 1. 处理 start_urls 列表（爬虫程序的入口）
    - 2. 编写 parse(response) 解析方法，解析 response

        [Selector, Selector] = response.xpath("//a/text()")
        [Unicode, Unicode] = response.xpath("//a/text()").extract()
        Unicode = response.xpath("//a/text()").extract_first()


        a. 提取 item 数据，交给pipeline保存处理
            yield item
        b. 提取 url 数据，构建请求交给调度器处理
            yield scrapy.Request(url, callback = self.parse_page)

5. 编写pipeline管道：打开pipelines.py文件，处理 item 数据的保存

6. 编写settings配置文件： 打开 settings.py 文件，处理项目的配置信息

7. 执行爬虫 ： scrapy crawl baidu


注意点1：start_urls 里的 url，不需要码农手动构建请求，Scrapy框架会自动处理；只有在 parse() 里的url需要自行构建请求。

注意点2：如果一个Scrapy项目下有多个spider，默认共享items、pipelines、middlewares和settings 文件功能。






1. 入口url ： http://www.itcast.cn/channel/teacher.shtml
2. 数据字段：

    #item_list = []

    def parse(self, response):
        node_list = response.xpath("//div[@class='li_txt']")

        for node in node_list:
            item = ItcastItem()
            #item['name'] = node.xpath("./h3/text()")[0].extract()
            item['name'] = node.xpath("./h3/text()").extract_first()
            item['title'] = node.xpath("./h4/text()").extract_first()
            item['info'] = node.xpath("./p/text()").extract_first()
            #item_list.append(item)
            yield item

        #return item_list



        item['name'] = node.xpath("./h3/text()").extract()
        1. 好处：根据下标可以取到不同位置的数据；
        2. 坏处：如果没有数据，强行下标取值则抛出异常


        item['name'] = node.xpath("./h3/text()").extract_first()
        1. 好处：取第一条数据的内容，如果数据不存在，则返回 None；如果数据存在则返回数据
        2. 坏处：只能取第一条数据的内容






itmes.py

position_name = scrapy.Filed()
position_link = scrapy.Filed()
position_type = scrapy.Filed()
people_number = scrapy.Filed()
work_location = scrapy.Filed()
publish_times = scrapy.Filed()



入口：




offset = 0
base_url = "https://hr.tencent.com/position.php?&start="
start_urls = [base_url + str(offset)]


def parse(self, response):

    node_list = response.xpath("//tr[@class='odd'] | //tr[@class='even']")

    for node in node_list:
        item = TencentItem()

        item["position_name"] = node.xpath("./td[1]/a/text()").extract_first()
        item["position_link"] = "https://hr.tencent.com/" + node.xpath("./td[1]/a/@href").extract_first()
        item["position_type"] = node.xpath("./td[2]/text()").extract_first()
        item["people_number"] = node.xpath("./td[3]/text()").extract_first()
        item["work_location"] = node.xpath("./td[4]/text()").extract_first()
        item["publish_times"] = node.xpath("./td[5]/text()").extract_first()

        yield item


    # if self.offset < 3830:
    #     self.offset += 10
    #     url = self.base_url + str(self.offset)

    #     yield scrapy.Request(url, callback = self.parse)

    #如果返回真，则表示到了最后一页；如果返回 None，表示没到最后一页
    if not response.xpath("//a[@class='noactive' and @id='next']").extract_first():
        next_url = "https://hr.tencent.com/" + response.xpath("//a[@id='next']/@href").extract_first()
        yield scrapy.Request(next_url, callback = self.parse)








"//a[@class='noactive' and @id='next']"

"//tr[@class='even'] || //tr[@class='odd']"




（广度优先的爬虫）
Spider : 从start_urls开始，再从返回的response自行提取新的链接，并发送请求。
                            （自行提取链接构建请求对象 yield 给引擎，并指定回调函数）


同一级 的多页数据抓取：

# 不属于完全的高并发
1. 通过偏移量控制：适用于不确定总页数、没有下一页链接点击情况（json）
2. 通过提取下一页链接控制：适用于不确定总页数，但是可以通过下一页获取所有的页面（常用）

# 属于完全高并发
3. 通过start_urls控制：适用于确定了总页数，直接通过 列表推导式构建所有的url地址列表



多级 页面数据抓取：
1. 将数据存储到相同的文件中：一个item对象，通过meta传递到callback回调函数中
2. 将数据存储到不同的文件中：多个item对象，在管道里通过 isinstance() 判断，再分别处理




字符串转列表：
s = "hello world byebye world"
l = s.split(" ")

l == ["hello", "world", "byebye", "world"]

列表转字符串：

ss = " ".join(l)
ss == "hello world byebye world"





（深度优先的爬虫）
CrawlSpider ： 从start_urls开始，自动从返回的response中提取新的链接，并发送请求。
                                （只要设置好一个提取规则，并指定回调函数）



Spider类：更灵活，用丰富的定制化抓取，适用的场景更多样化（json、翻页/不翻页，存储同一个文件/不同文件）
CrawlSpider类：比较死板，只能设定提取规则，辅助发送请求处理，适用于大型门户网站、论坛等多级页面抓取的场景


Rule(链接提取规则，回调函数，是否跟进继续提取=False)

Rule(LinkExtract(allow=r"链接规则"), callback="回调函数名" follow=True),


# 导入链接提取器
from scrapy.linkextractors import LinkExtractor

# 根据正则表达式规则，创建链接提取器对象
link_extractor = LinkExtractor(allow=r'position\.php\?&start=\d+')

# 通过extract_links处理指定的response响应，返回该响应中所有符合规则的链接
link_list = link_extractor.extract_links(response)

Rule(link_extractor, callback="...", process_links="process_links_method", follow=True)

def process_links_method(self, link_list)
# 获取每个链接对象的url
for link in link_list:
    link.url.replace(".", "。")

return link_list



# 提取当前页面里的所有链接
link_extractor = LinkExtractor()

# 提取当前页面里所有包含数字的链接
link_extractor = LinkExtractor(allow=r"\d+")

# 提取当前页面里所有包含数字的、但不包含id的链接
link_extractor = LinkExtractor(allow=r"\d+", deny=r"id")



大类
小类
文章（标题和内容）


如果没有callback，默认 follow=True；如果有callback，默认 follow=False


rules = [
    Rule(LinkExtract(allow=r"大类链接规则"), follow=True),
    Rule(LinkExtract(allow=r"小类链接规则"), follow=True),
    Rule(LinkExtract(allow=r"小类链接规则"), follow=True),
    Rule(LinkExtract(allow=r"小类链接规则"), follow=True),

    Rule(LinkExtract(allow=r"文章链接规则"), callback = "parse_page", follow=False)
]



战略上蔑视、战术上重视。



links = [lnk for lnk in rule.link_extractor.extract_links(response) if lnk not in seen]







# 获取指定结点下所有子节点的文本内容
response.xpath("//div[@id='head']").xpath("string(.)").extract_first()
"".join(response.xpath("//div[@id='head']//text()").extract())



https://list.suning.com/emall/showProductList.do?ci=262667&pg=03&cp=1&il=0&iy=0&adNumber=0&n=1&ch=4&sesab=AABAAB&id=IDENTIFYING&cc=755

https://list.suning.com/emall/showProductList.do?ci=262667&pg=03&cp=1&il=0&iy=0&adNumber=0&n=1&ch=4&sesab=AABAAB&id=IDENTIFYING&cc=755&paging=1&sub=0



ttps://list.suning.com/emall/showProductList.do?ci=262667&pg=03&cp=2&il=0&iy=0&adNumber=0&n=1&ch=4&sesab=AABAAB&id=IDENTIFYING&cc=755

https://list.suning.com/emall/showProductList.do?ci=262667&pg=03&cp=2&il=0&iy=0&adNumber=0&n=1&ch=4&sesab=AABAAB&id=IDENTIFYING&cc=755&paging=1&sub=0



https://ds.suning.cn/ds/generalForTile/000000000101511683__2_0070121234,000000000129203008__2_0070091573,000000000129414257_-755-2-0070142386-1--ds0000000006594.jsonp?callback=ds0000000006594





"/usr/lib/python2.7/"

"/usr/local/lib/python2.7/site-packages/"



start_urls里的url构建的请求，默认不做去重 dont_filter=True

def start_requests

Request(self, url, callback=None, headers=None, cookies=None, meta=None, dont_filter=False):




logging 日志：

settings.py : LOG_FILE、LOG_LEVEL

logging.info("hello world")



requetts.get(proxies = {"http" : "name:passwd@192.234.23.22:8888"})





User-Agent
Proxy
Cookies

匹配： ^(.*?): (.*?)$
替换： "\1" : "\2",




python_obj = json.load(fp)
json.dump(python_obj, fp)

python_obj = json.loads(json_str)
json_str = json.dumps(python_obj)



http://www.renren.com/PLogin.do

email : mr_mao_hacker@163.com
password : ALARMCHIME




offset = 0
http://capi.douyucdn.cn/api/v1/getVerticalRoom?limit=100&offset=

offset += 100


room_id
vertical_src
nickname
anchor_city




room_link
image_link
nick_name
anchor_city
image_path



def get_media_requests(self, item, info):
    return [Request(x) for x in item.get(self.images_urls_field, [])]

def item_completed(self, results, item, info):
    if isinstance(item, dict) or self.images_result_field in item.fields:
        item[self.images_result_field] = [x for ok, x in results if ok]
    return item




Linux 下查看文件熟练命令

ls | wc -l

