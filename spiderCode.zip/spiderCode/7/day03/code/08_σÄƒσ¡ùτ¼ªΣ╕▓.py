import re

# 原串: 就是让\表示原来本含义
print(len('a\nb')) # 3
print(len(r'a\nb')) # 4

print(r'a\nb' == 'a\nb') # False
print(r'a\nb' == 'a\\nb') # True

# 原串在正则中的使用

print(re.findall("a\nb", 'a\nb')) #['a\nb']
print(re.findall("a\nb", 'a\\nb')) #[]
print(re.findall("a\\nb", 'a\\nb')) #[]

# 原串在正则中作用: 可以忽略转移符的影响, 匹配内容有几个, 正则中就写几个
print(re.findall(r"a\\nb", 'a\\nb')) ['a\\nb']
