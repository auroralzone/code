
# 寻找POST的请求的URL
- 方案1
 - 在输入框中右键 -> 检查
 - form -> action 
 数据: 在该form表单中input中, 键就是name属性
- 方案2: 有些时候form表单中没有URL, 或者没有form表单, 怎么办呢? 
 - 可以使用network进行监听, 登录后界面可能会跳转, 最好勾选Preserve log, 为了避免页面跳转可以把账号或密码输入错误.
 - headers
   - URL就在上面
   - 数据就最下面 
  
# 如果处理使用js加密后数据或处理后的数据呢? 
解决方案
 1. 首先找对应js
    1. network -> initiators -> 发送请求的js -> 找到生成数据的js代码
    2. 使用search all files -> 使用URL特征字符串进行搜索
    3. 选择登录按钮->检查->在右边 Event-Listeners -> click -> js
 2. 分析js(调试js)
```js
    formSubmit: function() {
        var e, t = {};
        $(".login").addEventListener("click", function() {
            t.phoneNum = $(".phonenum").value,
            t.password = $(".password").value,
            e = loginValidate(t),
            t.c1 = c1 || 0,
            e.flag ? ajaxFunc("get", "http://activity.renren.com/livecell/rKey", "", function(e) {
                var n = JSON.parse(e).data;
                if (0 == n.code) {
                    t.password = t.password.split("").reverse().join(""),
                    setMaxDigits(130);
                    var o = new RSAKeyPair(n.e,"",n.n)
                      , r = encryptedString(o, t.password);
                    t.password = r,
                    t.rKey = n.rkey
                } else
                    toast("公钥获取失败"),
                    t.rKey = "";
                ajaxFunc("post", "http://activity.renren.com/livecell/ajax/clog", t, function(e) {
                    var e = JSON.parse(e).logInfo;
                    0 == e.code ? location.href = localStorage.getItem("url") || "" : toast(e.msg || "登录出错")
                })
            }) : toast(e.msg)
        })
```   
3. 在python中执行js生成我们想要的数据(或js翻译成为python)



i.setRequestHeader("X-Requested-With", "XMLHttpRequest"),
    i.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"