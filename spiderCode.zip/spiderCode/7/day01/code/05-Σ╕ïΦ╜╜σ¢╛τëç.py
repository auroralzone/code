import requests


response = requests.get('http://old.bz55.com/uploads/allimg/150210/139-150210134411-50.jpg')

# 把图片写入文件中
with open('a.jpg', 'wb') as f:
    f.write(response.content)
