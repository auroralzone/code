import threading
from queue import Queue
import time

# 创建队列对象
queue = Queue()

# 定义方法, 添加数据到队列中
def add_to_queue():
    for i in range(0, 100):
        print("添加{}".format(i))
        queue.put(i)

# 定义方法从队列中获取数据
def get_from_queue():
     while True:
        print(queue.get())
        time.sleep(0.0001)
        queue.task_done()


# 开两个线程执行上面的两个任务
t1 = threading.Thread(target=add_to_queue)
t1.setDaemon(True)
t1.start()

t2 = threading.Thread(target=get_from_queue)
t2.setDaemon(True)
t2.start()

# t1.join()
# # 由于t2执行的任务中有死循环, 不能join否则就结束不了
# t2.join()
queue.join()