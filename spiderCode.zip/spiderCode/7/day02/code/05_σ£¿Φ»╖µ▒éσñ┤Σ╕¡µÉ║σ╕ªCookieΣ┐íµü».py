import  requests

# 准备URL(只有登录后才能访问)
url= 'http://www.renren.com/965194180/profile'
# 请求头, 携带cookie信息访问登录后肚饿资源
headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',
    'Cookie': 'anonymid=jhmlyqwb-4h7id0; depovince=GW; _r01_=1; ick_login=d922aa8d-2bf6-48a4-913e-2b1527ac4128; first_login_flag=1; ln_uact=15565280933; ln_hurl=http://head.xiaonei.com/photos/0/0/men_main.gif; JSESSIONID=abc1hhM3ll-y-b6wIoAow; jebe_key=3a8c9688-8c1b-46ff-918d-42761808018a%7Cd1c66006be65eb42497ec9dcb5438885%7C1527300894282%7C1%7C1527300896180; wp_fold=0; jebecookies=7ec1d083-943c-42fb-a5c5-6b3be3a72c75|||||; _de=A64335C255985C873F16E7D5D4146F99; p=0aa5aa6cc4b0f1d908d705a133a2d49b0; t=3cefbe68d98123d10a941f99bb1effa40; societyguester=3cefbe68d98123d10a941f99bb1effa40; id=965194180; xnsid=65b74bc8; ver=7.0; loginfrom=null'
}

response = requests.get(url, headers=headers)
print(response.status_code)
print(response.content.decode())

