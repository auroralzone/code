#coding:utf-8

#from .spider import Spider
from .scheduler import Scheduler
from .downloader import Downloader
#from .pipeline import Pipeline

from ..http.request import Request
from ..item import Item

#from ..middlewares.spider_middlewares import SpiderMiddleware
#from ..middlewares.downloader_middlewares import DownloaderMiddleware
# 导入单例的logger对象
from ..utils.log import logger

from datetime import datetime


class Engine(object):
    def __init__(self, spiders, pipelines=[], spider_mids=[], downloader_mids = []):
        #self.spider = spider
        self.spiders = spiders
        self.scheduler = Scheduler()
        self.downloader = Downloader()
        self.pipelines = pipelines

        self.spider_mids = spider_mids
        self.downloader_mids = downloader_mids


    def start(self):
        """
            提供外部的访问接口，启动引擎
        """
        start = datetime.now()
        logger.info("start time : {}".format(start))

        self._start_engine()
        stop = datetime.now()
        logger.info("stop time : {}".format(stop))

        # 统计两个时间差的秒数
        time = (stop - start).total_seconds()
        logger.info("useing time : {}".format(time))


    def _start_engine(self):

        #[("baidu", baidu_spider), ("douban", douban_spider)]
        for spider_name, spider in self.spiders.items():
            # 1. Spider返回第一个入口请求
            #start_requests = self.spider.start_requests()
            # 1. 获取生成器中的每个请求，并做处理
            for start_request in spider.start_requests():

                for spider_mid in self.spider_mids:
                    # 2. 请求经过爬虫中间件做预处理并返回
                    start_request = spider_mid.process_request(start_request)

                # 3. 将预处理后的请求交给调度器处理
                self.scheduler.add_request(start_request)

            while True:
                # 4. 从调度器中获取一个请求
                request = self.scheduler.get_request()

                # 5. 判断请求是否为None，如果返回的Request是None，则表示队列为空，退出循环
                if request is None:
                    break

                # 5. 将请求交给下载器下载之前，奥给下载中间件做预处理并返回
                for downloader_mid in self.downloader_mids:
                    request = downloader_mid.process_request(request)

                # 6. 将预处理后请求交给下载器下载，并返回响应
                response = self.downloader.get_response(request)

                # 7. 将响应交给下载中间件做预处理并返回
                for downloader_mid in self.downloader_mids:
                    response = downloader_mid.process_response(response)

                # 8. 将响应交给爬虫解析，并返回 Item 或 Request
                #item_or_requests = self.spider.parse(response)
                #parse_func = self.spider.parse(response):

                # 查找Spider对象包含的 请求的callback，并返回该回调函数
                parse_func = getattr(spider, request.callback)

                # 将响应做为参数传给callback，parse_func就是一个可迭代的生成器
                for item_or_request in parse_func(response):
                    # 7. 判断Item 或 Request，并做对应处理，处理结束进入下一个while 循环
                    if isinstance(item_or_request, Request):
                        request = item_or_request

                        # 7.1 如果是请求对象，则通过爬虫中间件做预处理，再交给调度器
                        for spider_mid in self.spider_mids:
                            request = spider_mid.process_request(request)

                        self.scheduler.add_request(request)

                    else:
                        item = item_or_request

                        for spider_mid in self.spider_mids:
                            # 7.2 如果是Item对象，则通过爬虫中间件做预处理，再交给管道
                            item = spider_mid.process_item(item)

                        for pipeline in self.pipelines:
                            item = pipeline.process_item(item, spider)
                        # 所有管道处理完后，删除item对象（交还内存空间）
                        del(item)
