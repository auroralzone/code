#coding:utf-8


import scrapy

from Tencent.items import TencentItem

class TencentSpider(scrapy.Spider):
    name = "tencent"
    allowed_domains = ["hr.tencent.com"]

    offset = 0
    base_url = "https://hr.tencent.com/position.php?&start="
    start_urls = [base_url + str(offset)]


    def parse(self, response):

        node_list = response.xpath("//tr[@class='odd'] | //tr[@class='even']")

        for node in node_list:
            item = TencentItem()

            item["position_name"] = node.xpath("./td[1]/a/text()").extract_first()
            item["position_link"] = node.xpath("./td[1]/a/@href").extract_first()
            item["position_type"] = node.xpath("./td[2]/text()").extract_first()
            item["people_number"] = node.xpath("./td[3]/text()").extract_first()
            item["work_location"] = node.xpath("./td[4]/text()").extract_first()
            item["publish_times"] = node.xpath("./td[5]/text()").extract_first()

            # item 数据交给管道处理（需要自己实现）
            yield item


        if self.offset < 3830:
            self.offset += 10
            url = self.base_url + str(self.offset)

            # Request数据交给调度器处理（框架已经实现）
            yield scrapy.Request(url, callback = self.parse)
