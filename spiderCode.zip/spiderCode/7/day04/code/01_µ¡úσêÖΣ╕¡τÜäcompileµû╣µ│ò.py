import re

# 作用: 提高正则表达式的执行效率

# 编译正则表达式, 返回是一个编译好的正则表达式对象
regex = re.compile('\d+')

# 使用regex找数字
rs = regex.findall('abc124cd245ef')
print(rs)

# 替换
rs = regex.sub('_', 'abc124cd245ef')
print(rs)

# 在使用compile方法的时候,一定要记得re.S要放到compile方法中
regex = re.compile(".+",  re.S)
rs = regex.findall("abc\nef")
print(rs)