from selenium import webdriver
import json
import time
from selenium.webdriver.chrome.options import Options

'''
爬取斗鱼直播平台的所有房间信息
要求:
获取房间图片, 房间URL,房间标题,房间类别, 房间所有者, 房间热度信息
每一个房间的信息,以json格式保存到文件中, 每个房间占一行

步骤:
 1. 创建driver对象
 2. 请求直播所有分类的URL
    # https://www.douyu.com/directory/all
 3. 提取数据
 4. 保存数据
 5. 实现翻页
 6. 退出driver
'''

class DouYuSpider(object):

    def __init__(self):
        # 1. 创建driver对象
        op = Options()
        op.set_headless()
        self.driver = webdriver.Chrome(options=op)

        # 2. 请求直播所有分类的URL
            # https://www.douyu.com/directory/all
        self.driver.get('https://www.douyu.com/directory/all')
        # 3. 主机名
        self.host = 'https://www.douyu.com'


    def get_data(self):
        '''获取数据: 获取房间图片, 房间URL,房间标题,房间类别, 房间所有者, 房间热度信息'''
        # 先分组: 房间列表 li标签列表
        li_s = self.driver.find_elements_by_xpath('//*[@id="live-list-contentbox"]/li')
        # 遍历分组使用xpath提取数据
        data_list = []
        for li in li_s:
            item = {}

            try:
                # 获取房间图片,
                item['room_img'] = li.find_element_by_xpath('./a/span/img').get_attribute('src')
                # 房间URL
                item['room_url'] = self.host + li.find_element_by_xpath('./a').get_attribute('href')
                # 房间标题
                item['room_title'] = li.find_element_by_xpath('./a/div/div/h3').text
                # 房间类别,
                item['room_category'] = li.find_element_by_xpath('./a/div/div/span').text
                # 房间所有者
                item['room_author'] = li.find_element_by_xpath('./a/div/p/span[1]').text
                # 房间热度信息
                item['room_hot'] = li.find_element_by_xpath('./a/div/p/span[2]').text
                # print(item)
            except Exception as e:
                '''如果在真实开发中, 所有异常都要使用try处理, 如果有错误记录日志中, 如果错误比较严重, 你可以让程序自动发邮件给你'''
                print(e)
                print(item)

            data_list.append(item)
        # 实现分页
        # 根据class属性获取下一页按钮
        next_page = self.driver.find_elements_by_class_name('shark-pager-next')
        next_page = next_page[0] if len(next_page) != 0 else None

        return data_list, next_page

    def save_data(self, data_list):
        '''4. 保存数据'''
        # 一个租房信息以json格式保存到一行
        with open('douyu.txt', 'a', encoding='utf8') as f:
            for data in data_list:
                json.dump(data, f, ensure_ascii=False)
                f.write('\n')

    def run(self):
        #  3. 提取数据
        while True:
            data_list, next_page = self.get_data()
            #  4. 保存数据
            self.save_data(data_list)
            #  5. 实现翻页
            if next_page is not None:
                next_page.click()
                print('下一页')
                # 当页面是使用js动态生成的, 那么使用显示等待还是隐身等待都无效的
                # self.driver.implicitly_wait(10)
                # 只能使用强制等待
                time.sleep(3)
            else:
                break

        #  6. 退出driver
        self.driver.quit()



if __name__ == '__main__':
    dys = DouYuSpider()
    dys.run()