import requests

# 1. 获取session对象, 方法和requests一样
session = requests.session()

# 设置属性来设置请头, 每次使用该session对象发送请求都会自动带该请求头
session.headers = {
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36',
}

# 2. 登录URL和登录数据
login_url = 'http://www.renren.com/PLogin.do'
# 登录数据
data = {
    'email':'lideshan12@163.com',
    'password':'A123456'
}
# 3. 使用seesion对象,发送登录请求
response = session.post(login_url, data=data)
with open('home.html', 'wb') as f:
    f.write(response.content)
# 4. 使用该session去访问登录的资源
response = session.get('http://www.renren.com/223063923/profile')
with open('profile.html', 'wb') as f:
    f.write(response.content)

