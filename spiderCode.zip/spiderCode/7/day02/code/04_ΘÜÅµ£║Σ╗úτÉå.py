import random
import requests

# 1.'准备代理池(列表)
proxies_list = [
    {'http':'101.4.136.34:80'},
    {'http':'217.30.64.26:53281'},
    {'http':'153.149.170.54:3128'},
    {'http':'153.149.168.48:3128'},
    {'http':'62.182.207.26:53281'},
    {'http':'106.112.161.242:808'},
    {'http':'43.229.88.98:53281'},
    {'http':'121.8.98.198:80'},
    {'http':'39.108.234.144:80'},
    {'http':'125.120.201.68:808'},
    {'http':'91.107.5.210:51816'},
    {'http':'103.28.149.180:3128'},
    {'http':'36.67.20.251:52136'},
    {'http':'116.90.225.154:53281'},
     {'http':'151.106.25.232:1080'},
    {'http':'120.24.216.39:60443'},
    {'http':'202.183.32.173:80'},
    {'http':'103.228.119.125:8080'},
    {'http':'202.93.128.98:3128'},
    {'http':'153.149.169.205:3128'},
]


for i in range(0, 10):
    # 2. 随机选出一个代理
    # 随机去列表中取出一个代理
    proxies = random.choice(proxies_list)
    # print(proxies)
    try:
        # 3. 使用这个随机代理发送请求
        # response = requests.get('http://www.baidu.com', proxies=proxies)
        # 指定超时参数
        response = requests.get('http://www.baidu.com', proxies=proxies, timeout=2)
        print(response.status_code)
    except Exception as ex:
        print("代理{}不可用".format(proxies))
        # 如果代理不可用就从列表删除
        proxies_list.remove(proxies)
