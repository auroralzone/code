
# 如何定位生成密码的js的位置
- 方案1: network的initiator字段找到发送请求的js -> 找谁调用这个方法的方法
- 方案2: 右上角 search all 请求URL的特征字符串
- 方案3: 检查登录按钮的元素 -> 右边 -> Event-Listeners -> click -> js

<!-- 设置请求头 -->
  i.setRequestHeader("X-Requested-With", "XMLHttpRequest"),
  i.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"),

# 调试js
  
# 模拟人人手机端登录

```js
  t.phoneNum = $(".phonenum").value,
  t.password = $(".password").value,
  e = loginValidate(t),
  t.c1 = c1 || 0,
  e.flag ? ajaxFunc("get", "http://activity.renren.com/livecell/rKey", "", function(e) {
      var n = JSON.parse(e).data;
      if (0 == n.code) {
          t.password = t.password.split("").reverse().join(""),
          setMaxDigits(130);
          var o = new RSAKeyPair(n.e,"",n.n)
            , r = encryptedString(o, t.password);
          t.password = r,
          t.rKey = n.rkey
      } else
          toast("公钥获取失败"),
          t.rKey = "";
      ajaxFunc("post", "http://activity.renren.com/livecell/ajax/clog", t, function(e) {
          var e = JSON.parse(e).logInfo;
          0 == e.code ? location.href = localStorage.getItem("url") || "" : toast(e.msg || "登录出错")
      })
```

  
## 数据分类与处理方法
  
准备登录URL:
  http://activity.renren.com/livecell/ajax/clog
准备登录数据
  rkey请求URL: http://activity.renren.com/livecell/rKey
  返送请求获取数据
  解析获取data中数据,赋值n 
  首先使用js2py创建js执行环境context
  向js执行环境中添加数据: t(phoneNum, password, c1),n
  让js执行环境去加载需要js

  js = '''
      t.password = t.password.split("").reverse().join(""),
      setMaxDigits(130);
      var o = new RSAKeyPair(n.e,"",n.n)
        , r = encryptedString(o, t.password);
      t.password = r,
      t.rKey = n.rkey
  '''
  执行js, 执行后执行环境中t就是我们要发送登录请数据
  发送登录请求,获取登录后的数据

# 数据分类和处理方法
- 非结构化数据: html
- 处理: 正则,xpath

- 结构化数据: 
  - json: json模块/jsonpath
  - xml: re,xpath     