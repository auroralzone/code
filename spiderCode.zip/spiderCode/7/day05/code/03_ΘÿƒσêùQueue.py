from queue import Queue

# 创建队列对象, 没有上限
# queue = Queue()

# 创建队列, 指定最大元素格式为3
queue = Queue(maxsize=3)


# 添加数据
queue.put(1)
queue.put(2)
queue.put(3)
print("size %d " % queue.qsize())
# 如果队列满了, 在调用put方法, 阻塞线程一直等待
# queue.put(4)
# queue.put_nowait(4)  # 满了就报错queue.Full

# 获取数据
#获取队列中的元素个数
print("size %d " % queue.qsize())
print("unfinished_tasks %d " %queue.unfinished_tasks)
print(queue.get())
queue.task_done()
#获取队列中的元素个数
print("size %d " % queue.qsize())
print("unfinished_tasks %d " %queue.unfinished_tasks)
print(queue.get())
queue.task_done()
#获取队列中的元素个数
print("size %d " % queue.qsize())
print("unfinished_tasks %d " %queue.unfinished_tasks)
print(queue.get())
queue.task_done()
#获取队列中的元素个数
print("size %d " % queue.qsize())
print("unfinished_tasks %d " %queue.unfinished_tasks)


# get方法,如果队列为空了, 就会阻塞线程, 一直等待
# print(queue.get())
# 如果没有数据不等, 直接报错queue.Empty
# print(queue.get_nowait())
# #获取队列中的元素个数
# print("size %d " % queue.qsize())

# 让主线等待, 等待到unfinished_tasks为0的时候位置
queue.join()