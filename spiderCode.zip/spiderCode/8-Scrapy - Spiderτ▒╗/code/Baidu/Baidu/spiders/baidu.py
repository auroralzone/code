# -*- coding: utf-8 -*-
import scrapy


class BaiduSpider(scrapy.Spider):
    # 爬虫名(必须且唯一）
    name = 'baidu'
    # 爬虫允许爬取的域名范围
    allowed_domains = ['baidu.com', 'qq.com', '163.com']

    # 爬虫的程序入口
    start_urls = ['http://www.baidu.com/', 'http://www.qq.com/']

    def parse(self, response):
        title = response.xpath("//title/text()")[0].extract()

        with open(title + ".html", "w") as f:
            f.write(response.body)

