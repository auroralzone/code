from selenium import webdriver
import requests
import yudama
import time

driver = webdriver.Chrome()
driver.get('https://www.douban.com/')

driver.find_element_by_id('form_email').send_keys('583349285@qq.com')
driver.find_element_by_id('form_password').send_keys('lw19860404')

# 识别验证码:
# -URL对应的图片是不变的: 直接请求
# -URL对应的图片是变化的: 需要发送请求的时候, 带cookie信息

img_tg = driver.find_elements_by_id('captcha_image')
if len(img_tg) != 0:
    # 请求获取验证码图片
    img_url = img_tg[0].get_attribute('src')
    # 获取图片响应
    response = requests.get(img_url)
    # 通过云打码平台, 识别图片验证码
    code = yudama.indetify(response.content)
    # 在验证码输入框, 填写验证码
    driver.find_element_by_id('captcha_field').send_keys(code)

# 点击登录按钮, 进行登录
driver.find_element_by_class_name('bn-submit').click()

time.sleep(3)
# 退出driver
driver.quit()