from selenium import webdriver
import time

# 创建Chrome浏览器的驱动
driver = webdriver.Chrome()

# 访问百度首页
driver.get('http://www.baidu.com')


# 打印当前URL
print(driver.current_url)
# 获取当前页面的内容, 即页面内容源码
# print(driver.page_source)
# 获取cookie信息
[{'domain': '.baidu.com', 'httpOnly': False, 'name': 'H_PS_PSSID', 'path': '/', 'secure': False, 'value': '1423_26260_21107_18559_20718'},...]
# print(driver.get_cookies())
# 把cookies列表,转换为字典; {name:value}

cookies = {cookie['name']:cookie['value'] for cookie in driver.get_cookies()}
print(cookies)


time.sleep(1)
# 只是关闭当前浏览器窗口, 如果浏览上只有这个一个窗口, 浏览器会退出, 但是chromedriver不会退出
# driver.close()
# 退出浏览器和chromedriver
driver.quit()
