#coding:utf-8

# 1. 70% 左右的商业项目，用的还是Python2
# 2. 用Py2 还是 Py3 ，是由公司团队决定
# 3. 水桶效应，用的模块取支持版本最小的。


# Linux下终端：默认字符串编码为utf-8
# Windows终端：默认字符串编码是gbk

# 用于字符串写入时，解释器编码和要写入的字符串编码处理不一致，导致 UnicodeEncodeError
# 默认Python2 解释器编码环境是ascii的，所以不能处理包含中文的Unicode字符串
# 如果使用默认ascii编码进行文件写入时，
#   如果数据有中文，就报出 UnicodeEncodeError；
#   如果数据全部是英文+数字，那么ascii可以直接处理，则不会报错

# 解决方案：
#   1. 程序员手动将Unicode转为gbk、utf-8
#   2. 将数据转码，转为utf-8，写入文件时，指定编码为utf-8
        #Python3: open("xxx.txt", "wb", encoding='utf-8')
        #Python2: import codecs
        #         codecs.open("xxx.txt", "w", encoding="utf-8")

#   3. 将解释器环境改为utf-8，再写入utf-8数据:
#        字符串是Unicode，如果程序员没有转码，Python解释器会尝试进行转码处理（默认ASCII处理不了中文），所有可以修改解释器环境为UTF-8，就可以处理中文了。


import sys
reload(sys)
sys.setdefaultencoding("utf-8")


import json
# Python内置的csv文件读写模块
import csv


def json_to_csv():
    # 读取json文件的对象
    json_file = open("aqi.json", "r")
    # 写入csv文件的对象
    csv_file = open("json_to_csv.csv", "w")

    # 把json文件的字符串内容转为对应的Python数据类型
    item_list = json.load(json_file)
    # 创建一个csv文件写入对象，可以将数据写入到指定的csv文件中
    csv_writer = csv.writer(csv_file)

    # 表头部分， 一维列表
    # [日期、城市、AQI]
    table_title = item_list[0].keys()

    # 数据部分，多行数据，二维列表
    # [ [2013, 北京, 45], [2012, 上海]]
    data_list = [item.values() for item in item_list]

    # 写一行表头数据，参数是一个一维列表
    csv_writer.writerow(table_title)
    # 一次性写多行数据部分，参数是一个二维嵌套列表
    csv_writer.writerows(data_list)

    # 关闭文件，将内存缓冲区数据写入到磁盘文件中
    csv_file.close()
    json_file.close()


# [{日期 : xx, AQI : xxx, city : xxxx}, {}]

# 日期 城市 AQI pm2_5
# 20.  xxx  12  10
# 21.  xxx  13  34


def read_csv():
    csv_file = open("xxx.csv", "rb")
    csv_reader = csv.reader(csv_file)

    # 迭代每一行
    for line in csv_reader:
        print(line)
    csv_file.close()

if __name__ == "__main__":
    json_to_csv()
