#coding:utf-8


class Response(object):
    """
        构建响应对象的类
    """
    def __init__(self, url, status_code, headers, body, encoding, request):
        self.url = url
        self.status_code = status_code
        self.headers = headers
        self.body = body
        self.encoding = encoding
        self.request = request
