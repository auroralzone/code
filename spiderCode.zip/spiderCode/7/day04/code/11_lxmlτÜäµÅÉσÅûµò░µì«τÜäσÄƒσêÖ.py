from lxml import etree

text = '''
<div> <ul> 
<li class="item-1"><a >first item</a></li> 
<li class="item-1"><a href="link2.html">second item</a></li> 
<li class="item-inactive"><a href="link3.html">third item</a></li> 
<li class="item-1"><a href="link4.html">fourth item</a></li> 
<li class="item-0"><a href="link5.html">fifth item</a>
</ul> </div>

'''

# 把字符串的html转为为lxml中Element对象
# 强调: HTML有自动修正html或xml功能, 修正后原有文档结构就可能发生变化, 如果你xpath总是不对, 这个时候,打印转换后html, 按照这个html区写xpath
element = etree.HTML(text)
print(element)
# 查看element对应的字符串
print(etree.tostring(element).decode())

# 我们提取所有属性为item-1的li下的a标签中文本和href属性
# 使用xpath提取数据的元素:
#    先分组, 获取包含数据的标签(节点)列表
#    遍历标签列表, 再使用xpath提取数据

# 先分组, 获取包含数据的所有a标签
a_s = element.xpath('//li[@class="item-1"]/a')
for a in a_s:
    item = {}
    item['href'] = a.xpath('./@href')
    item['href'] = item['href'][0] if len(item['href']) != 0 else None
    item['title'] = a.xpath('./text()')
    item['title'] = item['title'][0] if len(item['title']) != 0 else None

    print(item)



