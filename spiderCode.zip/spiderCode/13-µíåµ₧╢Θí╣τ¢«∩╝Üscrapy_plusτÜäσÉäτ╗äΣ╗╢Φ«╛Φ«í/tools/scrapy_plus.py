敏捷开发：尽快将项目上线，之后再慢慢更新内容。


Python爬虫框架：Scrapy、PySpider (提供了Web界面)



一、所有爬虫程序/框架必须遵循的流程：

1. 构建请求 （url、method、headers、params、ormdata）
2. 发送HTTP请求，获取对应HTTP响应
3. 解析响应：
    1. 继续抓取的url地址，再次构建请求发送
    2. 需要保存的目标数据，做对应保存处理
4. 直到所有的请求发送结束，程序结束。



二、现代软件架构设计：高内聚，低耦合。

模块化编程：
高内聚：一个功能模块内，数据关系紧密，只做一件事（UNIX哲学），接收数据，返回结构
低耦合：各个功能模块之间关系不紧密，如果某个模块功能升级、修改，不需要改动其他模块。



三种数据：
请求(Request) : url、headers、params、formdata、method
响应(Response) ： url、status_code、headers、body、request
数据(Item) ： data


五个核心组件：

1. 爬虫组件 Spider ：
    1. 构建 初始化的 请求对象(Request)，程序入口
    2. 接收并解析 响应对象(Response)，返回 新的 请求对象(Request)/ 数据对象(Item)

2. 调度器组件Scheduler：
    1. 接收并保存 请求对象(Request)，返回 请求对象(Request)
    2. 请求对象(Request) 去重

3. 下载器组件Downloader：
    1. 接收并发送 请求对象(Request)，返回 响应对象(Response)

4. 管道组件Pipeline：
    1. 接收 数据对象(Item)，进行后续处理

5. 引擎组件Engine：
    1. 负责驱动各个组件的执行，保证各个组件数据传递和返回，让框架能够正常执行。
    2. 负责启动整个框架的运作。

两个中间件：
1. 爬虫中间件：
    1. 处理 Spider-Engine之间的 Request 和 Item

2. 下载中间件：
    1. 处理 Engine-Downloder之间的 Request 和 Response


三、各个组件提供的对象和方法

1. 爬虫组件 Spider ：
    1. start_requests() : 构建 初始化的 请求对象(Request)，程序入口
    2. parse() : 接收并解析 响应对象(Response)，返回 新的 请求对象(Request)/ 数据对象(Item)

2. 调度器组件Scheduler：
    1. add_request() : 接收并保存 请求对象(Request)，
    2. _filter_request() : 请求对象(Request) 去重
    3. get_reqeust() : 返回 请求对象(Request)

3. 下载器组件Downloader：
    1. get_response() : 接收并发送 请求对象(Request)，返回 响应对象(Response)

4. 管道组件Pipeline：
    1. process_item() : 接收 数据对象(Item)，进行后续处理

5. 引擎组件Engine：
    1. 负责驱动各个组件的执行，保证各个组件数据传递和返回，让框架能够正常执行。
    2. 负责启动整个框架的运作。

两个中间件：
1. 爬虫中间件：
    1. process_item() / process_reqeust(): 处理 Spider-Engine之间的 Request 和 Item

2. 下载中间件：
    1. process_request() / process_response() : 处理 Engine-Downloder之间的 Request 和 Response



四、框架的目录结构：

- scrapy_plus
    - __init__.py
    - core
        - __init__.py
        - spider.py
        - scheduler.py
        - downloader.py
        - pipeline.py
        - engine.py

    - http
        - __init__.py
        - request.py
        - response.py
    - item.py



