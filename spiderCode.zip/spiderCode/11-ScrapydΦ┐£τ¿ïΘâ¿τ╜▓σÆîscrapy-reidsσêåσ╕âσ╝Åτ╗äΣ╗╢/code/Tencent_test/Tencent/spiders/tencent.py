#coding:utf-8


import scrapy

from Tencent.items import TencentItem

class TencentSpider(scrapy.Spider):
    name = "tencent"
    allowed_domains = ["hr.tencent.com"]

    #offset = 0
    global base_url  # Python3 加这句代码
    base_url = "https://hr.tencent.com/position.php?&start="
    #start_urls = [base_url + str(offset)
    
    start_urls = [base_url + str(page) for page in range(0, 3771, 10)]


    # 处理职位列表页（10个职位6条信息）
    def parse(self, response):
        # 提取当前页面中所有职位的结点列表
        node_list = response.xpath("//tr[@class='odd'] | //tr[@class='even']")

        # 迭代每个结点，并提取职位数据
        for node in node_list:
            item = TencentItem()

            item["position_name"] = node.xpath("./td[1]/a/text()").extract_first()
            item["position_link"] = "https://hr.tencent.com/" + node.xpath("./td[1]/a/@href").extract_first()
            item["position_type"] = node.xpath("./td[2]/text()").extract_first()
            item["people_number"] = node.xpath("./td[3]/text()").extract_first()
            item["work_location"] = node.xpath("./td[4]/text()").extract_first()
            item["publish_times"] = node.xpath("./td[5]/text()").extract_first()



            yield scrapy.Request(
                # meta 的作用是将当前方法里的变量，通过字典的方式传递给回调函数，回调函数中通过response的meta属性来获取字典数据

                # meta的主要作用：就是在不同的方法里，传递item（只能传递给下面的回调函数）
                url = item["position_link"], meta = {"obj" :item}, callback = self.parse_page
            )

            #yield item

    # 处理职位详情页（处理每个职位的2条信息）
    def parse_page(self, response):

        item = response.meta["obj"]

        item['position_zhize'] = "\n".join(response.xpath("//ul[@class='squareli']")[0].xpath("./li/text()").extract())

        item['position_yaoqiu'] = "\n".join(response.xpath("//ul[@class='squareli']")[0].xpath("./li/text()").extract())

        yield item









