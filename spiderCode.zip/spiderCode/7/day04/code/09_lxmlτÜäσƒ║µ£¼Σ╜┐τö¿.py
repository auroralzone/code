from lxml import etree

text = '''
<div> <ul> 
<li class="item-1"><a href="link1.html">first item</a></li> 
<li class="item-1"><a href="link2.html">second item</a></li> 
<li class="item-inactive"><a href="link3.html">third item</a></li> 
<li class="item-1"><a href="link4.html">fourth item</a></li> 
<li class="item-0"><a href="link5.html">fifth item</a>
</ul> </div>

'''

# 把字符串的html转为为lxml中Element对象
# 强调: HTML有自动修正html或xml功能, 修正后原有文档结构就可能发生变化, 如果你xpath总是不对, 这个时候,打印转换后html, 按照这个html区写xpath
element = etree.HTML(text)
print(element)
print(type(element))
# 查看element对应的字符串
print(etree.tostring(element).decode())

