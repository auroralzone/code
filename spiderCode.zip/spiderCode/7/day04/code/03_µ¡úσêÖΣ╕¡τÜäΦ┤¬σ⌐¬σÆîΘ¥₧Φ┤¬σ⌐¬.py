import re

string_a = '<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">\n\t\t<meta http-equiv="content-type" content="text/html;charset=utf-8">\n\t\t<meta content="always" name="referrer">\n        <meta name="theme-color" content="#2932e1">'
# 正则默认都是贪婪的: 尽可能多的匹配内容 .*, .+
# ret = re.findall("<.*>", string_a, re.S)
# 非贪婪: 尽可能少的匹配内容, .+?, .*?
# ret = re.findall("<.*?>", string_a, re.S)

ret = re.findall("<.*>", string_a)
print(len(ret))
print(ret)