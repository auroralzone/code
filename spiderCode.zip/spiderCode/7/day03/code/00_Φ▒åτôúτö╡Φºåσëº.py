import requests
import json

class DoubanMovieSpider(object):

    def __init__(self):
         # URL
         # 1. 修改URL,start参数值进行占位
         self.url = 'https://m.douban.com/rexxar/api/v2/subject_collection/filter_tv_american_hot/items?&=18&loc_id=108288'
         # 准备请求头
         self.headers = {
             'Referer': 'https://m.douban.com/tv/american',
             'User-Agent': 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Mobile Safari/537.36'
        }

    def get_data_from_url(self, url):
        '''根据URL,获取URL对应二进制数据'''
        response = requests.get(url, headers=self.headers)
        return response.content

    def get_movie_list(self, json_str):
        ''' 解析json数据, 获取电影信息列表'''
        dic = json.loads(json_str)
        return dic['subject_collection_items']

    def save_movie_list(self, move_list):
        '''把电影信息存储文件, 每一个电影信息占一行'''
        with open('douban_movie.txt', 'a', encoding='utf8') as f:
             for movie in move_list:
                json.dump(movie, f, ensure_ascii=False)
                f.write('\n')

    def run(self):
        '''入口'''

        # 准备URL
        #  - 热映电影json数据URL
        #  https://m.douban.com/rexxar/api/v2/subject_collection/movie_showing/items?start=0&count=18&loc_id=108288
        # 定义一个变量, 用于记录当前页的起始索引号
        start = 0
        while True:
            url = self.url.format(start)
            print(url)
            # 发送请求,获取数据
            json_str = self.get_data_from_url(url)
            # print(json_str)
            # 解析json数据, 获取电影信息列表
            movie_list = self.get_movie_list(json_str)
            # print(movie_list)
            # 把电影信息存储文件, 每一个电影信息占一行
            self.save_movie_list(movie_list)
            # 计算下一页start
            start += 18
            # 结束: 如果电影列表中的数据小于18
            if len(movie_list) < 18:
                break


if __name__ == '__main__':
    dbms = DoubanMovieSpider()
    dbms.run()
