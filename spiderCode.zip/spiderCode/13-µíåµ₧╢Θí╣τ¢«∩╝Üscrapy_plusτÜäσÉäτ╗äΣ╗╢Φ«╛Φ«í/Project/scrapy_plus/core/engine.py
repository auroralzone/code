#coding:utf-8

from .spider import Spider
from .scheduler import Scheduler
from .downloader import Downloader
from .pipeline import Pipeline

from ..http.request import Request
from ..item import Item



class Engine(object):
    def __init__(self):
        self.spider = Spider()
        self.scheduler = Scheduler()
        self.downloader = Downloader()
        self.pipeline = Pipeline()


    def start():
        """
            提供外部的访问接口，启动引擎
        """
        self._start_engine()

    def _start_engine(self):
        start_request = self.spider.start_requests()

        self.scheduler.add_request(start_request)

        while True:
            request = self.scheduler.get_request()

            # 如果返回的Request是None，则表示队列为空，退出循环
            if request is None:
                break

            response = self.downloader.get_response(request)

            item_or_request = self.spider.parse(response)

            if isinstance(item_or_request, Request):
                self.scheduler.add_request(item_or_request)
            else:
                self.pipeline.process_item(item_or_request)


