#coding:utf-8


# try:
#     from Queue import Queue
# except ImportError:
#     from queue import queue

# pip install six : 第三方模块，提供了py2和py3 模块的兼容问题
from six.moves.queue import Queue

from ..utils.log import logger

class Scheduler(object):
    def __init__(self):
        self.queue = Queue()
        self._filter_set = set()

    def add_request(self, request):
        """
            对请求去重，并添加到请求队列中
        """

        if not self._filter_request(request):
            self.queue.put(request)
            self._filter_set.add(request.url)

    def get_request(self):
        """
            胡群殴请求队列中的请求
        """
        try:
            # 如果队列为空，则抛出异常
            return self.queue.get(False)
        except:
            # 如果有异常，表示请求队列为空，返回None
            logger.warning("Queue is empty!")
            return None


    def _filter_request(self, request):
        if request.url in self._filter_set:
            logger.warning("{} filter.".format(request.url))
            return True
        else:
            return False


