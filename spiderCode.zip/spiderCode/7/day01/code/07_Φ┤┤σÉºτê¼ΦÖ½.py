import requests

class TiebaSpider(object):

    def __init__(self, ba_name, start, end):
        self.ba_name = ba_name
        self.start = start
        self.end = end
        # 准备URL的模板
        self.url_pattern = 'https://tieba.baidu.com/f?kw={}&ie=utf-8&pn={}'
        self.headers ={
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 11_0 like Mac OS X) AppleWebKit/604.1.38 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1'
        }


    def get_url_list(self):
        '''获取URL列表'''
        # url_list = []
        # for i in range(self.start, self.end+1):
        #     url_list.append(self.url_pattern.format(self.ba_name, (i-1)*50))
        # return url_list
        # 列表生成式
        return [self.url_pattern.format(self.ba_name, (i-1)*50) for i in range(self.start, self.end+1)]

    def get_page_from_url(self, url):
        '''发送请求,获取响应数据'''
        response = requests.get(url, headers = self.headers)
        return response.content.decode()

    def save_page(self, page, page_num):
        '''保存页面内容到本地'''
        file_name = "{}_第{}页.html".format(self.ba_name, page_num)
        # 写入文件
        with open(file_name, 'w', encoding='utf8') as f:
            f.write(page)


    def run(self):
        '程序入口方法, 主干逻辑'
        # 准备URL列表
        url_list = self.get_url_list()
        # print(url_list)
        # 发送请求, 获取响应数据
        for url in url_list:
            page = self.get_page_from_url(url)
            # 计算页码
            page_num = url_list.index(url) + 1
            # 把页面内容保存到本地
            self.save_page(page, page_num)

if __name__ == '__main__':

    tbs = TiebaSpider('美食',1, 3)
    tbs.run()