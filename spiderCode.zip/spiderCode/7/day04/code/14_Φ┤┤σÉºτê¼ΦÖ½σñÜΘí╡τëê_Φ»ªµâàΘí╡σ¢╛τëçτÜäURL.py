import requests
from lxml import etree
import json

'''
先获取单页的所有的标题和URL
准备URL:
 http://tieba.baidu.com/mo/q---8DF4A6278C21C5F331E3F89A7D56AE96%3AFG%3D1-sz%40320_240%2C-1-3-0--2--wapp_1527567444963_895/m?kw=%E6%9D%8E%E5%86%B0%E5%86%B0&lp=5011&lm=&pn=40
发送请求,获取数据
提取数据, URL和标题列表
保存数据

# 我们要求详情页中提取所有图片
<img class="BDE_Image" src="http://c.hiphotos.baidu.com/forum/w%3D96%3Bq%3D45%3Bg%3D0/sign=f844fdce4aa7d933bfa8e875963aec27/c729b899a9014c0899f1ef7f027b02087af4f434.jpg?&amp;src=http%3A%2F%2Fimgsrc.baidu.com%2Fforum%2Fpic%2Fitem%2Fc729b899a9014c0899f1ef7f027b02087af4f434.jpg" />

'''



class TiebaSpider(object):

    def __init__(self, tb_name):
        self.tb_name = tb_name
        self.url = 'http://tieba.baidu.com/mo/q---8DF4A6278C21C5F331E3F89A7D56AE96%3AFG%3D1-sz%40320_240%2C-1-3-0--2--wapp_1527567444963_895/m?kw={}&lp=5011&lm=&pn=0'
        self.url = self.url.format(tb_name)
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Linux; Android 5.0; SM-G900P Build/LRX21T) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Mobile Safari/537.36'
        }
        # 用于URL进行拼接, 前面的那一部分URL
        self.pre_url = 'http://tieba.baidu.com/mo/q---8DF4A6278C21C5F331E3F89A7D56AE96%3AFG%3D1-sz%40320_240%2C-1-3-0--2--wapp_1527567444963_895/'


    def get_page_from_url(self, url):
        '''发送请求获取页面数据'''
        response = requests.get(url, headers=self.headers)
        # return response.content.decode()
        return response.content

    def get_data_from_page(self, page):
        ''' # 提取数据, URL和标题列表'''
        # ValueError: Unicode strings with encoding declaration are not supported. Please use bytes input or XML fragments without declaration.
        # 如果解析的内容上面声明编码方式, 就不能使用字符串, 要使用二进制
        # <?xml version="1.0" encoding="UTF-8"?>
        element = etree.HTML(page)
        # 先分组, 获取所有主题a标签(在class属性包含i的标签下面)
        a_s = element.xpath('//div[contains(@class, "i")]/a')
        # 创建列表用于保存数据
        data_list = []

        for a in a_s:
            item = {}
            item['title'] = a.xpath('./text()')[0]
            item['detail_url'] = self.pre_url + a.xpath('./@href')[0]
            item['img_urls'] = self.get_images_from_url(item['detail_url'])
            data_list.append(item)

        # 提取下一页的URL
        next_url = element.xpath("//a[text()='下一页']/@href")
        next_url = self.pre_url + next_url[0] if len(next_url) != 0 else None

        return data_list, next_url

    def get_images_from_url(self, detail_url):
        '''提取详情页所有图片URL'''
        # 定义一个列表,用于图片URL
        img_list = []

        while detail_url is not None:
            # 获取页面内容
            page = self.get_page_from_url(detail_url)
            # 解析页面内容,提取图片URL
            element = etree.HTML(page)
            # 提取图片上的URL
            images = element.xpath('//img[@class="BDE_Image"]/@src')
            for img in images:
                # URL的解码
                img = requests.utils.unquote(img)
                # print(img)
                img = img.split('src=')[1]
                print(img)
                img_list.append(img)
            # print(img_list)
            # 提取下一页的URL
            next_url = element.xpath("//a[text()='下一页']/@href")
            detail_url = self.pre_url + next_url[0] if len(next_url) != 0 else None

        return  img_list


    def save_data(self, data_list):
        '''保存数据'''
        file_name = self.tb_name+".txt"
        with open(file_name, 'a', encoding='utf8') as f:
            for data in data_list:
                json.dump(data, f, ensure_ascii=False)
                f.write('\n')


    def run(self):
        # 准备URL:
        url = self.url

        while url is not None:
            # 发送请求,获取数据
            page = self.get_page_from_url(url)
            # 提取数据, URL和标题列表
            data_list, url = self.get_data_from_page(page)
            # 保存数据
            self.save_data(data_list)


if __name__ == '__main__':
    tbs = TiebaSpider('做头发')
    tbs.run()