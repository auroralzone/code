# 猴子补丁
from gevent import monkey
monkey.patch_all()
from gevent.pool import Pool


import requests
from lxml import etree
import json
from queue import Queue
import time


'''
 线程池修改协程池:
  只需要换包就可以
  from multiprocessing.dummy import Pool
  该为:
    猴子补丁
    from gevent import monkey
    monkey.patch_all()
    from gevent.pool import Pool    
'''

class QiuBaiSpider(object):
    def __init__(self):
        # 准备URL的模板
        self.url_pattern = 'https://www.qiushibaike.com/8hr/page/{}/'
        # 请求头
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
        }
        #  1. 在init方法创建URL队列, 响应队列, 数据队列
        self.url_queue = Queue()
        self.response_queue = Queue()
        self.data_queue = Queue()
        # 创建线程池对象
        self.pool = Pool(6)

    def add_url_to_queue(self):
        '''2. get_url_list 该为添加URL到URL的队列中.更名为 add_url_to_queue'''
        '''用于获取URL的列表'''
        for i in range(1, 14):
            self.url_queue.put(self.url_pattern.format(i))

    def add_page_to_queue(self):
        ''' 3. get_page_from_url 首先去URL队列中取出URL,发送请求获取响应, 把响应内容添加响应队列 .更名为 add_page_to_queue'''

        while True:
            url = self.url_queue.get()
            ''' 发送请求, 获取响应数据'''
            response = requests.get(url, headers=self.headers)

            print(response.status_code)
            if response.status_code != 200:
                # url_queue 的 unfinished_tasks 增加1
                self.url_queue.put(url)
            else:
                #  把响应内容添加响应队列
                self.response_queue.put(response.content)
            # 到这儿, 当前这个URL的任务已经处理完成了
            # 让 url_queue 的 unfinished_tasks 减少1
            self.url_queue.task_done()


    def add_data_to_queue(self):
        ''' 4. get_data_from_page 从响应队列中取出页面数据, 解析数据, 解析结果放到数据队列.更名为 add_data_to_queue'''
        '''解析页面内容, 获取我们需要的数据'''
        '''每个段子包含发送人头像URL,昵称,性别,段子内容, 好笑数,评论数'''
        while True:
            # 从响应队列中取出页面数据,
            page = self.response_queue.get()
            # 创建页面对应的element
            element = etree.HTML(page)
            # 先分组, 获取包含段子信息的div列表
            div_s = element.xpath('//*[@id="content-left"]/div')
            # 定义列表, 用于存储段子数据
            data_list = []
            # 遍历分组的列表, 再在遍历处理的div标签的基础上使用xpath提取内容
            for div in div_s:
                item = {}
                item['head_url'] = self.get_first_from_list(div.xpath('./div[1]/a[1]/img/@src'))
                item['nick_name'] = self.get_first_from_list(div.xpath('./div[1]/a[2]/h2/text()'))
                gender_class = self.get_first_from_list(div.xpath('./div[1]/div/@class'))
                if gender_class is not None:
                    item['gender'] = 'man' if gender_class.find('man') != -1 else 'women'
                else:
                    item['gender'] = None

                item['dz_content'] = div.xpath('./a[1]/div/span[1]/text()')[0]
                item['funny_count'] = div.xpath('./div/span[1]/i/text()')[0]
                item['comments_count'] = div.xpath('./div/span/a/i/text()')[0]
                # 把段子信息添加列表中
                data_list.append(item)
            #  解析结果放到数据队列.
            self.data_queue.put(data_list)
            # 页面数据处理完了, 该任务完成了
            self.response_queue.task_done()

    def get_first_from_list(self, ls):
        '''获取列表中第一个元素, 如果没有就返回None'''
        return ls[0] if len(ls) != 0 else None


    def save_data(self):
        ''' 5. save_data  去数据队列中取出数据列表, 进行保存 '''
        '''保存数据'''
        while True:
            data_list = self.data_queue.get()
            with open('qiubai_协程池.txt', 'a', encoding='utf8') as f:
                for data in data_list:
                    json.dump(data, f, ensure_ascii=False)
                    f.write('\n')
            # 数据处理完成
            self.data_queue.task_done()

    def execute_more_tasks(self, target, count):
        for i in range(0, count):
            # 使用线程池执行异步任务
            self.pool.apply_async(target)

    def run(self):
        # 开线程执行任务
        # t1 = threading.Thread(target=self.add_url_to_queue)
        # t1.start()
        #
        # t2 = threading.Thread(target=self.add_page_to_queue)
        # t2.setDaemon(True)
        # t2.start()
        #
        # t3 = threading.Thread(target=self.add_data_to_queue)
        # t3.setDaemon(True)
        # t3.start()
        #
        # t4 = threading.Thread(target=self.save_data)
        # t4.setDaemon(True)
        # t4.start()
        self.execute_more_tasks(self.add_url_to_queue, 1)
        self.execute_more_tasks(self.add_page_to_queue, 3)
        self.execute_more_tasks(self.add_data_to_queue, 2)
        self.execute_more_tasks(self.save_data, 1)

        # 让主线等待一下
        time.sleep(0.01)

        #  让主线线程等待每一个队列任务完成
        self.url_queue.join()
        self.response_queue.join()
        self.data_queue.join()


if __name__ == '__main__':
    qbs = QiuBaiSpider()
    qbs.run()