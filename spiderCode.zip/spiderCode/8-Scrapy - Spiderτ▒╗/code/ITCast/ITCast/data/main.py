#!/usr/bin/env python
# -*- coding:utf-8 -*-

from scrapy import cmdline

#cmdline.execute(["scrapy", "crawl", "itcast"])
cmdline.execute("scrapy crawl itcast".split(" "))
