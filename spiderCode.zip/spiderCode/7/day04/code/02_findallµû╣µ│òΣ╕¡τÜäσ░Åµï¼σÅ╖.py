import re

rs = re.findall(r"a.+bc", "a\nbc", re.DOTALL) # re.DOTALL 与 re.S 等价
print(rs) # a\nbc

rs = re.findall(r"a(.+)bc", "a\nbc", re.DOTALL)
print(rs) # \n

rs = re.findall(r"a(.+)b(.+)c", "a\nb\nc", re.DOTALL)
print(rs) # \n

# 结论: 如果findall方法中, 正则中没有小括号, 整个正则字符进行匹配查找
#       如果有小括号,只查找与小括号匹配内容, 小阔号两边是用于负责定位的