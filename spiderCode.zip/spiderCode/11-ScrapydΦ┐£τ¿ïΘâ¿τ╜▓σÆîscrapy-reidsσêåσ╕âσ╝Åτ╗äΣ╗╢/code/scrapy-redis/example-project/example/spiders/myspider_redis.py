#coding:utf-8
from scrapy_redis.spiders import RedisSpider


# 1. 修改爬虫类
class MySpider(RedisSpider):
#class MySpider(scrapy.Spider):

    """Spider that reads urls from redis queue (myspider:start_urls)."""
    name = 'myspider_redis'
    # redis数据库的一个键，爬虫启动后，会第一时间取数据库里读取这个键对应的值，再将这个值保存到start_urls
    # lpush myspider:start_urls http://www.baidu.com

    # 2. 添加redis_key，删除start_urls
    redis_key = 'myspider:start_urls'
    #start_urls = ['http://www.baidu.com']

    # 3. 设置域名范围
    #allowed_domains = ['baidu.com']


    def parse(self, response):
        return {
            'name': response.css('title::text').extract_first(),
            'url': response.url,
        }
