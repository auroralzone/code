# -*- coding: utf-8 -*-
import scrapy
import logging

#from scrapy import log
#log.msg("xxxxx", level=log.info)


class TestSpider(scrapy.Spider):
    name = 'test'
    allowed_domains = ['baidu.com']
    start_urls = ['http://www.baidu.com/']

    def parse(self, response):
        logging.info("This is a info msg")
        #logging.log(logging.WARNING, "This is a warning msg")
