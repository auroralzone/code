# -*- coding: utf-8 -*-

# Define here the models for your spider middleware
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/spider-middleware.html



from settings import USER_AGENT_LIST

import random

class UserAgentMiddleware(object):
    """
        每个请求都会切换User-Agent
    """
    def process_request(self, request, spider):
        user_agent = random.choice(USER_AGENT_LIST)
        request.headers["User-Agent"] = user_agent
        #print(request.headers["User-Agent"])


class ProxyMiddleware(object):
    """
        每个请求都会切换代理Ip
    """
    def process_request(self, request, spider):
        proxy = "maozhaojun:ntkn0npx@114.67.142.128:16816"
        request.meta["proxy"] = "http://" + proxy

