# -*- coding=utf-8 -*-

import scrapy

from ITCast.items import ItcastItem


class ItcastSpider(scrapy.Spider):

    # 爬虫名
    name = "itcast1"
    # 允许抓取的域名范围
    allowed_domains = ["itcast.cn"]

    # 入口的url地址列表
    start_urls = ["http://www.itcast.cn/channel/teacher.shtml"]

    # 保存数据的列表
    item_list = []

    # parse 解析方法，用来解析每个响应
    def parse(self, response):

        # 1. 先提取所有数据的结点组
        node_list = response.xpath("//div[@class='li_txt']")

        # 2. 迭代结点组列表，获取每个结点组
        for node in node_list:
            # 3. 定义item对象保存数据
            item = ItcastItem()

            # 4. 取出每个结点组的各个阶段数据，并保存到itme中
            item['name'] = node.xpath("./h3/text()").extract_first()
            item['title'] = node.xpath("./h4/text()").extract_first()
            item['info'] = node.xpath("./p/text()").extract_first()

            # 5. 每次获取一个item数据，就保存到item_list列表中
            self.item_list.append(item)

        # 最后返回item_list给引擎，引擎根据 scrapy crawl 的 -o 输出到指定文件中
        # json、csv、xml

        return self.item_list



