
# 进程是分配系统资源基本单位, 每一个进程中数据都是独立, 所以普通Queue不能进行进程间通信的.
# 怎么办? 这个时候我们需要使用进程专用队列 multiprocessing.JionableQueue
from multiprocessing import JoinableQueue
import time
from multiprocessing import Process

# 创建队列对象
queue = JoinableQueue()


# 定义方法, 添加数据到队列中
def add_to_queue():
    for i in range(0, 100):
        print("添加{}".format(i))
        queue.put(i)

        # 定义方法从队列中获取数据


def get_from_queue():
    while True:
        print(queue.get())
        time.sleep(0.0001)
        queue.task_done()

p1 = Process(target=add_to_queue)
p1.daemon = True
p1.start()

p2 = Process(target=get_from_queue)
p2.daemon = True
p2.start()


# 让主进程等待队列任务完成
# 子进程启动比较慢, 队列中还没有添加数据 _unfinished_tasks为0
# 怎么办呢? 让主进程等待一下, 让子进程可以向队列中添加数据(任务)
# time.sleep(0.01)
# 让主进程等待p1进程完成
p1.join()
# 让主进程等待队列任务完成
queue.join()