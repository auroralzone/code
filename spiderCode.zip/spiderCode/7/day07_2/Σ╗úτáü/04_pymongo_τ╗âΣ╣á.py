from pymongo import MongoClient
import time

'''
使用python向集合t3中插入1000条文档, 文档包含_id和name
id的值为0, 1, 2, 3,...999
name的值为py0, py2, ....

查询显示出_id为100整数的倍数的文档, 如100, 200, 300...

'''

class PymongoTest(object):

    def __init__(self):
        # 创建客户端对象, 链接到MongoDB的服务器
        client = MongoClient()
        # 获取要操作集合
        self.collection = client['test']['t3']

    def insert_data(self):
        '''
        使用python向集合t3中插入1000条文档,文档包含_id和name
        _id的值为0,1,2,3,...999
        name的值为py0,py2,....
        '''
        # 1. 生成一个数据列表
        datas = [{"_id":i, "name":"py{}".format(i)}  for i in range(0, 1000)]
        # 2. 向集合中插入多条数据
        self.collection.insert_many(datas)

    def find_data(self):
        '''查询显示出_id为100整数的倍数的文档, 如100, 200, 300'''
        # 自定查询条件
        # cursor = self.collection.find({"$where": "function(){ return this._id % 100 == 0 && this._id != 0; }"})
        # for data in cursor:
        #     print(data)
        # 0.08398985862731934
        # 1. 查询所有数据
        cursor = self.collection.find()
        # 2. 使用python进行过滤
        for data in cursor:
            if data['_id'] % 100 == 0 and data['_id'] != 0:
                print(data)
        # 0.008594989776611328


if __name__ == '__main__':
    pt = PymongoTest()
    # pt.insert_data()
    # float, 单位s
    start = time.time()
    pt.find_data()
    end = time.time()
    cost = end - start
    print(cost)