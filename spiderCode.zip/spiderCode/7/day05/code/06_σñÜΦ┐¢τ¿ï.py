from multiprocessing import Process
import time

def func(name):
    for i in range(0, 10):
        print(name)
        time.sleep(0.001)

# 创建进程执行任务
p1 = Process(target=func, args=('进程1', ))
p1.daemon = True
p1.start()

p2 = Process(target=func, args=('进程2', ))
p2.daemon = True
p2.start()

# 等待字进程完成
p1.join()
p2.join()
