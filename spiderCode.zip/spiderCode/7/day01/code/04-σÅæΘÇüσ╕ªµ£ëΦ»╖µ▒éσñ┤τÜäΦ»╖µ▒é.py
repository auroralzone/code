import requests

# response = requests.get('http://www.baidu.com')
# # print(response.request.headers)
#
#
# print(response.content.decode())


# 我要告诉百度服务器我是 浏览器
headers ={
    'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
}

# 发送带有请求头的请求
response = requests.get('http://www.baidu.com', headers=headers)
print(response.content.decode())