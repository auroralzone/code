# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

import scrapy
import os
import logging

from scrapy.pipelines.images import ImagesPipeline
from settings import IMAGES_STORE

# sr/local/lib/python2.7/site-package/scrapy


class DouyuImagesPipeline(ImagesPipeline):

    def get_media_requests(self, item, info):
        #return [Request(x) for x in item.get(self.images_urls_field, [])]
        yield scrapy.Request(item['image_link'])

    def item_completed(self, results, item, info):
        #print(results)

        # 原始图片保存路径
        source_path = IMAGES_STORE + [x["path"] for ok, x in results if ok][0]

        # 指定新的图片保存路径
        item["image_path"] = IMAGES_STORE + item["nick_name"] + ".jpg"

        try:
            # 根据路径修改图片名 os.rename(old_name, new_name)
            os.rename(source_path, item["image_path"])
        except Exception as e:
            print(e)
            logging.error("Images %s rename failed" % source_path)

        return item


# results = [(True, {'url': 'https://rpic.douyucdn.cn/amrpic-180608/2025735_1226.jpg', 'path': 'full/da718682e049de10d56cb0b9adf14f410bae2d06.jpg', 'checksum': 'fb9f5f137508a8829dc8f2a314900a00'})]



# class DouyuPipeline(object):
#     def process_item(self, item, spider):
#         return item
