import requests
import re
import json


'''
    分页: 
      URL规律明显
      https://www.guokr.com/ask/highlight/?page=1
      https://www.guokr.com/ask/highlight/?page=2
      https://www.guokr.com/ask/highlight/?page=3
      并且页数就是100页,固定
      可以使用URL列表
'''

class GuokrSpider(object):

    def __init__(self):
        # 1. URL中变化地方就使用{}进行占位
        self.url = 'https://www.guokr.com/ask/highlight/?page={}'
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'
        }
        # 2. 生成URL列表
        self.url_list = [self.url.format(i) for i in range(1, 101)]


    def get_page_from_url(self, url):
        # print(url)
        ''' # 发送请求获取页面数据'''
        response = requests.get(url, headers=self.headers)
        # 返回响应的字符串数据
        return response.content.decode()

    def get_data_from_page(self, page):
        '''# 解析数据, 提取需要的内容'''
        # <h2><a target="_blank" href="https://www.guokr.com/question/668948/">子弹能射穿多少本书，与那一摞书本的本数多少有何关系？</a></h2>

        data_list = re.findall('<h2><a target="_blank" href="(.+?)">(.+?)</a></h2>', page, re.S)
        # print(data_list)
        return data_list

    def save_data(self, data_list):
        '''保存数据, 一条问答保存一行'''
        with open('goukr.txt', 'a', encoding='utf8') as f:
            for data in data_list:
                json.dump(data, f, ensure_ascii=False)
                f.write('\n')

    def run(self):
        # 准备URL
        # https://www.guokr.com/ask/highlight/
        # 遍历URL列表
        for url in self.url_list:
            # 发送请求获取页面数据
            page = self.get_page_from_url(url)
            # 解析数据, 提取需要的内容
            data_list = self.get_data_from_page(page)
            # 保存数据
            self.save_data(data_list)


if __name__ == '__main__':
    gkr = GuokrSpider()
    gkr.run()