import requests

# 准备代理字典
# proxies = {
#     # 'http': 'http://121.8.98.198:80'
#     'http': 'http://151.106.25.229:1080'
# }

# 付费代理, 需要账号和密码
proxies = {
    # 'http': 'http://用户名:密码@121.8.98.198:80'
}


# 使用代理发送请求
response = requests.get('http://www.biadu.com', proxies=proxies)
print(response.content.decode())