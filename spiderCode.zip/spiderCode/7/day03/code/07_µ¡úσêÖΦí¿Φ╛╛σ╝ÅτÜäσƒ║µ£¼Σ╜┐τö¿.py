import re

print(re.findall('a', 'abc'))
print(re.findall('[abc]', 'abc'))
print(re.findall('.', 'ab.c'))
print(re.findall('\.', 'ab.c'))
print(re.findall('.', 'abc\n123', re.S))
print(re.findall('.', 'abc\n123', re.DOTALL))

# 预定义字符类
print(re.findall('\d', 'ab12c34'))
print(re.findall('\D', 'ab12c34'))
print(re.findall('\s', 'ab 12\rc\t3\n4 '))
print(re.findall('\S', 'ab 12\rc\t3\n4 '))
print(re.findall('\w', 'ab12c$#34_中文'))
print(re.findall('\W', 'ab12c$#34_中文'))

# 数量词

# print(re.findall('.*', 'abc\n123\n456'))
print(re.findall('.+', 'abc\n123\n456'))
print(re.findall('.+', 'abc\n123\n456', re.S))
# print(re.findall('.?', 'abc\n123\n456', re.S))
print(re.findall('.{2,}', 'abcdef\n123\n456'))
print(re.findall('.{2,4}', 'abcdef\n123\n456'))


